const router = require("express").Router();
const controller = require("./financial.controller");

router.post("/", controller.addUser);
router.get("/", controller.getListUsers);
router.get("/:financialId", controller.getById);
router.get("/search", controller.userSearch);
router.put("/", controller.updateUser);
router.delete("/:financialId", controller.removeUser);

module.exports = router;
