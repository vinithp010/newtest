const router = require("express").Router();

router.use("/v1", require("./v1/financial.route"));

module.exports = router;