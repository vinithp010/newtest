"use strict";

const router = require("express").Router();
const controller = require("./document.controller");
const upload = require("../../../helpers/multer.helper");

router.post("/forBorrower/:borrowerId/upload", upload.single("docFile"), controller.uploadDocument);
router.post("/forBorrower/:borrowerId", controller.addForBorrower);
router.get("/", controller.getAll);
router.get("/forBorrower/:borrowerId", controller.getForBorrower);
router.get("/search/forBorrower/:borrowerId", controller.searchForBorrower);
router.put("/forBorrower/:borrowerId", controller.updateForBorrower);
router.delete("/forBorrower/:borrowerId", controller.removeForBorrower);

module.exports = router;
