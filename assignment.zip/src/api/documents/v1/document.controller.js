const responses = require("../../../helpers/api-response/response.function");
const service = require("./document.service");
const s3Helper = require("../../../helpers/s3.helper");
const documentSchemas = require("./document.validation");

const TAG = "document.controller";

const addForBorrower = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.addForBorrower: `, req.body);

  service.addToProcessor(req.body, (error, result) => {
    if (error) {
      console.log(`${TAG}.addForBorrower.Processor.error: `, error);
    }

    console.log(`${TAG}.addForBorrower.Processor.result: `, result);

    const validationResult = documentSchemas.addDocumentsSchema.validate(req.body);
    console.log(`${TAG}.addForBorrower: `, validationResult);
    if (validationResult.error)
      return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);

    service.addForBorrower(
      {
        partnerUserId: req.body.partner_user_id,
        selfieImage: req.body.selfie_image,
        residentialPOA: req.body.poa_resdential,
        aadharXml: req.body.aadhar_xml,
        panValidationResponse: req.body.pan_validation_response,
        sanctionLetter: req.body.sanction_letter,
        agreement: req.body.agreement,
        deviceIp: req.body.ip_address,
        createTimestamp: req.body.date_and_timestamp,
        panImage: req.body.pan_image,
        uuid: req.body.uuid,
        createdBy: req.body.created_by,
        updatedBy: req.body.updated_by
      },
      (error, result) => {
        if (error) {
          console.log(`${TAG}.addForBorrower.error: `, error);
          return responses.badRequestResponse(res, borrowerId, error["message"]);
        }

        console.log(`${TAG}.addForBorrower.result: `, result);
        return responses.successResponse(
          res,
          borrowerId,
          result,
          "Documents for the borrower has been successfully added!"
        );
      }
    );
  });
};

const uploadDocument = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.uploadDocument: `, req.body);

  s3Helper(borrowerId, req.file, (error, result) => {
    if (error) {
      console.log(`${TAG}.uploadDocument.s3.error: `, error);
      return responses.internalFailureResponse(res, borrowerId, null, error.message);
    }

    console.log(`${TAG}.uploadDocument.s3.result: `, result);
    service.uploadDocument(borrowerId, req.body.fileColumn, result, (error, result) => {
      if (error) {
        console.log(`${TAG}.uploadDocument.error: `, error);
        return responses.badRequestResponse(res, borrowerId, error["message"]);
      }

      console.log(`${TAG}.uploadDocument.result: `, result);
      return responses.successResponse(res, borrowerId, result, "Documents has been successfully uploaded!");
    });
  });
};

const getAll = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.getAll: `);

  service.getAll((error, result) => {
    if (error) {
      console.log(`${TAG}.getAll.error: `, error);
      return responses.badRequestResponse(res, borrowerId, error["message"]);
    }

    console.log(`${TAG}.getAll.result: `, result);
    return responses.successResponse(res, borrowerId, result, "Documents has been successfully fetched!");
  });
};

const getForBorrower = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.getForBorrower: `);

  service.getForBorrower(borrowerId, (error, result) => {
    if (error) {
      console.log(`${TAG}.getForBorrower.error: `, error);
      return responses.badRequestResponse(res, borrowerId, error["message"]);
    }

    console.log(`${TAG}.getForBorrower.result: `, result);
    return responses.successResponse(
      res,
      borrowerId,
      result,
      "Documents for the borrower has been successfully fetched!"
    );
  });
};

const searchForBorrower = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.searchForBorrower: `);
};

const updateForBorrower = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.updateForBorrower: `);
};

const removeForBorrower = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.removeForBorrower: `);

  service.deleteDocumentsForBorrower(borrowerId, (error, result) => {
    if (error) {
      console.log(`${TAG}.removeForBorrower.error: `, error);
      return responses.badRequestResponse(res, borrowerId, error["message"]);
    }

    console.log(`${TAG}.removeForBorrower.result: `, result);
    return responses.successResponse(
      res,
      borrowerId,
      result,
      "Documents for the borrower has been successfully removed!"
    );
  });
};

module.exports = {
  uploadDocument,
  addForBorrower,
  getAll,
  getForBorrower,
  searchForBorrower,
  updateForBorrower,
  removeForBorrower
};
