const Joi = require("joi");

const addDocumentsSchema = Joi.object().keys({
  partner_user_id: Joi.string().required().alphanum().max(1000),
  selfie_image: Joi.string().optional().alphanum().max(1000),
  poa_resdential: Joi.string().required().alphanum().max(1000),
  aadhar_xml: Joi.string().required().alphanum().max(1000),
  pan_validation_response: Joi.string().required().alphanum().max(1000),
  sanction_letter: Joi.string().required().alphanum().max(1000),
  agreement: Joi.string().required().alphanum().max(1000),
  ip_address: Joi.string().required().alphanum().max(1000),
  date_and_timestamp: Joi.date().required(),
  pan_image: Joi.string().required().alphanum().max(1000),
  uuid: Joi.number().required().min(1)
});

module.exports = {
  addDocumentsSchema
};
