const db = require("./../../../../database/models/index");

const TAG = "document.service";

const TDocumentProcessor = db.TDocumentProcessor;
const TDocument = db.TDocument;
const TDocumentExtended = db.TDocumentExtended;

function addToProcessor(data, callback) {
  TDocumentProcessor.create({
    uuid: null,
    documentData: JSON.stringify(data)
  })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function addForBorrower(data, callback) {
  TDocument.create(data)
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function uploadDocument(borrowerId, fileColumn, s3Object, callback) {
  TDocument.update({ fileColumn: s3Object.location }, { where: { uuid: borrowerId } })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getAll(callback) {
  TDocument.findAll()
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getForBorrower(borrowerId, callback) {
  TDocument.findOne({ uuid: borrowerId })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function updateForBorrower(borrowerId, data, callback) {
  TDocument.update(data, { where: { uuid: borrowerId } })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function removeForBorrower(borrowerId, data, callback) {
  TDocument.delete({ where: { uuid: borrowerId } })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

module.exports = {
  uploadDocument,
  addToProcessor,
  addForBorrower,
  getAll,
  getForBorrower,
  // searchForBorrower,
  updateForBorrower,
  removeForBorrower
};
