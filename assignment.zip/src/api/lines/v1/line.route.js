const router = require("express").Router();
const controller = require("./line.controller");

router.post("/", controller.addLine);
router.get("/", controller.getAll);
router.get("/:lineId", controller.getById);
router.get("/search", controller.searchForLine);
router.put("/:lineId", controller.updateLine);
router.delete("/:lineId", controller.removeLine);

module.exports = router;
