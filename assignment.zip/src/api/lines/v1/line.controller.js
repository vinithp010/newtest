const responses = require("../../../helpers/api-response/response.function");
const service = require("./line.service");
const documentSchemas = require("./line.validation");

const TAG = "line.controller";

const addLine = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.addLine: `, req.body);

  service.addToProcessor(req.body, (error, result) => {
    if (error) {
      console.log(`${TAG}.addLine.Processor.error: `, error);
    }

    console.log(`${TAG}.addLine.Processor.result: `, result);

    const validationResult = documentSchemas.createLineSchema.validate(req.body);
    console.log(`${TAG}.addLine: `, validationResult);
    if (validationResult.error)
      return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);

    service.addLine(
      {
        uuid: req.body.uuid,
        monthlyIncome: req.body.monthly_income,
        lineAmount: req.body.line_amount
      },
      (error, result) => {
        if (error) {
          console.log(`${TAG}.addLine.error: `, error);
          return responses.badRequestResponse(res, borrowerId, error["message"]);
        }

        console.log(`${TAG}.addLine.result: `, result);
        return responses.successResponse(res, borrowerId, result, "Line has been created successfully!");
      }
    );
  });
};

const getAll = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.getAll: `);

  service.getAll((error, result) => {
    if (error) {
      console.log(`${TAG}.getAll.error: `, error);
      return responses.badRequestResponse(res, borrowerId, error["message"]);
    }

    console.log(`${TAG}.getAll.result: `, result);
    return responses.successResponse(res, borrowerId, result, "Lines has been successfully fetched!");
  });
};

const getById = async (req, res) => {
  const lineId = req.params.lineId;
  console.log(`${TAG}.getById: `);

  service.getById(lineId, (error, result) => {
    if (error) {
      console.log(`${TAG}.getById.error: `, error);
      return responses.badRequestResponse(res, lineId, error["message"]);
    }

    console.log(`${TAG}.getById.result: `, result);
    return responses.successResponse(res, lineId, result, "Line has been successfully fetched!");
  });
};

const searchForLine = async (req, res) => {};

const updateLine = async (req, res) => {
  const lineId = req.params.lineId;
  console.log(`${TAG}.updateLine: `, req.body);

  service.addToProcessor(req.body, (error, result) => {
    if (error) {
      console.log(`${TAG}.updateLine.Processor.error: `, error);
    }

    console.log(`${TAG}.updateLine.Processor.result: `, result);

    const validationResult = documentSchemas.updateLineSchema.validate(req.body);
    console.log(`${TAG}.updateLine: `, validationResult);
    if (validationResult.error)
      return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);

    service.updateLine(
      lineId,
      {
        uuid: req.body.uuid,
        amPartnerLineId: req.body.am_line_id,
        monthlyIncome: req.body.monthly_income,
        updatedLineAmount: req.body.updated_line_amount,
        updatedLoanAgreement: req.body.updated_loan_agreement,
        updatedSanctionLetter: req.updated_sanction_letter
      },
      (error, result) => {
        if (error) {
          console.log(`${TAG}.updateLine.error: `, error);
          return responses.badRequestResponse(res, lineId, error["message"], { borrowerId: lineId });
        }

        console.log(`${TAG}.updateLine.result: `, result);
        return responses.successResponse(res, lineId, result, "Agreement docs updated successfully!");
      }
    );
  });
};

const removeLine = async (req, res) => {
  const lineId = req.params.lineId;
  console.log(`${TAG}.removeLine: `);

  service.removeLine(lineId, (error, result) => {
    if (error) {
      console.log(`${TAG}.removeLine.error: `, error);
      return responses.badRequestResponse(res, null, error["message"], { lineId });
    }

    console.log(`${TAG}.removeLine.result: `, result);
    return responses.successResponse(res, borrowerId, result, "Line for the borrower has been successfully removed!");
  });
};

module.exports = {
  addLine,
  getAll,
  getById,
  searchForLine,
  updateLine,
  removeLine
};
