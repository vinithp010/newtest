const db = require("./../../../../database/models/index");

const TAG = "line.service";

const TLineProcessor = db.TLineProcessor;
const TLine = db.TLine;
const TLineExtended = db.TLineExtended;

const TDocument = db.TDocument;

function addToProcessor(data, callback) {
  TLineProcessor.create({
    uuid: null,
    lineData: JSON.stringify(data)
  })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function addLine(data, callback) {
  TLine.create(data)
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getAll(callback) {
  TLine.findAll()
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getById(lineId, callback) {
  TLine.findOne({ id: lineId })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function updateLine(lineId, data, callback) {
  TLine.update(data, { where: { id: lineId }, returning: true })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function removeLine(lineId, callback) {
  TLine.delete({ where: { id: lineId } })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

module.exports = {
  addToProcessor,
  addLine,
  getAll,
  getById,
  updateLine,
  removeLine
};
