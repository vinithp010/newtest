const Joi = require("joi");

const createLineSchema = Joi.object().keys({
  uuid: Joi.number().required().min(1),
  monthly_income: Joi.number().min(1000).required(),
  line_amount: Joi.number().min(100).required()
});

const updateLineSchema = Joi.object().keys({
  uuid: Joi.number().required().min(1),
  am_line_id: Joi.string().min(10).max(30).required(),
  monthly_income: Joi.number().min(1000).required(),
  updated_line_amount: Joi.number().min(100).required(),
  updated_loan_agreement: Joi.string().required(),
  updated_sanction_letter: Joi.string().required()
});

module.exports = {
  createLineSchema,
  updateLineSchema
};
