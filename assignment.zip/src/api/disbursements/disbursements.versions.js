const router = require("express").Router();

router.use("/v1", require("./v1/disbursements.route"));

module.exports = router;