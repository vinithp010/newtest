const router = require("express").Router();
const controller = require("./disbursements.controller");

router.post("/", controller.addDisbursement);
router.get("/", controller.getListDisbursements);
router.get("/:disbursementId", controller.getById);
router.get("/search", controller.disbursementSearch);
router.put("/", controller.updateDisbursement);
router.delete("/:disbursementId", controller.removeDisbursement);

module.exports = router;
