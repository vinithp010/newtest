// joi validations come hear
const Joi = require('joi');
const createDisbursementSchema = Joi.object().keys({
    borrowerId: Joi.number().required().messages({
        'Number.base': `"borrowerId" should be a type of 'Number'`,
        'Number.empty': `"borrowerId" cannot be an empty field`,
        'any.required': `"borrowerId" is a required field`
    }),
    partnerUserId: Joi.string().trim().required().messages({
        'string.base': `"partnerUserId" should be a type of 'text'`,
        'string.empty': `"partnerUserId" cannot be an empty field`,
        'any.required': `"partnerUserId" is a required field`
    }),
    lineId: Joi.number().required().messages({
        'number.base': `"lineId" should be a type of 'Number'`,
        'number.empty': `"lineId" cannot be an empty field`,
        'number.required': `"lineId" is a required field`
    }),
    loanId: Joi.number().required().messages({
        'number.base': `"loanId" should be a type of 'Number'`,
        'number.empty': `"loanId" cannot be an empty field`,
        'number.required': `"loanId" is a required field`
    }),
    disbursementAmount: Joi.number().precision(2).required().messages({
        'number.base': `"monthlyIncome" should be a type of "Number"`,
        'number.empty': `"monthlyIncome" cannot be an empty field`,
        'number.required': `"monthlyIncome" is a required field`,
    }),
    utrNumber: Joi.string().required().messages({
        'string.base': `"utr" should be a type of "text"`,
        'string.empty': `"utr" cannot be an empty field`,
        'string.required': `"utr" is a required field`,
    }),
    disbursementDate: Joi.date().required().messages({
        'date.base': `"date" must be a valid date`,
        'date.required': `"date" is a required field`,
    }),
});

const validateDisbursementSchema = async (dataToValidate) => {
    return await createDisbursementSchema.validate(dataToValidate, { abortEarly: false, allowUnknown: true });
}

module.exports = {
    validateDisbursementSchema,
}