const { Op } = require("sequelize");
const db = require("../../../../database/models");

const TAG = "disbursements.service";

const Disbursement = db.TDisbursement;
const Partner = db.TPartner;
const Loan = db.TLoans;
const Line = db.TLine;
const DisbursementProcessingData = db.TDisbursementProcessingData;
const DisbursementExtended = db.TDisbursementExtended;

const getBorrower = async (borrowerId) => {
    try {
        return await Partner.findOne({
            where: { id: borrowerId },
            raw: true
        });
    } catch (error) {
        return error;
    }
}
const getLine = async (lineId) => {
    try {
        return await Line.findOne({
            where: { id: lineId },
            raw: true
        });
    } catch (error) {
        return error;
    }
}
const getLoan = async (loanId) => {
    try {
        return await Loan.findOne({
            where: { id: loanId },
            raw: true
        });
    } catch (error) {
        return error;
    }
}
const createDisbursementProcessingData = async (data, remark) => {
    try {
        return await DisbursementProcessingData.create({
            disbursementData: JSON.stringify(data),
            remark: JSON.stringify(remark)
            // createdBy: req.user.id
        });
    } catch (error) {
        return error
    }
}
const createDisbursement = async (data) => {
    try {
        const createData = await Disbursement.create(data);
        return createData;
    } catch (error) {
        return error
    }
}

module.exports = {
    getBorrower,
    getLine,
    getLoan,
    createDisbursementProcessingData,
    createDisbursement,
    // getDisbursementByUUID,
    // getDisbursementExtendedByDisbursementId,
    // updateDisbursementExtended,
    // createDisbursementExtended,
}