const uuidv4 = require('uuid');
const responses = require("../../../helpers/api-response/response.function");
const service = require("./disbursements.service");
const { validateDisbursementSchema } = require("./disbursements.validation");
const { snakeToCamel } = require('../../../helpers/utils.logger');

const TAG = "disbursements.controller";


const validateDate = (dtValue) => {
   var dtRegex = new RegExp(/^\d{4}-(0[1-9]|1[0-2])-([0-2]\d|3[01]) (0\d|1\d|2[0-3]):[0-5]\d:[0-5]\d$/);
   // (/\b\d{4}[\/-]\d{1,2}[\/-]\b\d{1,2} (0\d|1[01]):[0-5]\d:[0-5]\d$\b/);
   return dtRegex.test(dtValue);
}

const addDisbursement = async (req, res) => {
  try {
    console.log(`${TAG}.addDisbursement: `, req.body);
    const requestData = {};
    for (const key in req.body) {
      requestData[snakeToCamel(key)] = req.body[key];
    }
    // console.log(requestData)
    const validations = [];
    let borrowerId = null;
    let lineId = null;
    let loanId = null;
    const requestValidation = await validateDisbursementSchema(requestData, { "convert": true });
    if (requestData.borrowerId) {
      const borrower = await service.getBorrower(requestData.borrowerId);
      if (!borrower) {
        validations.push({
          message: 'Borrower not found'
        });
      } else {
        requestData.borrowerId = borrower.id;
        borrowerId = borrower.id;
      }
    }
    if (requestData.lineId) {
      const line = await service.getLine(requestData.lineId);
      if (!line) {
        validations.push({
          message: 'Line not found'
        });
      } else {
        requestData.lineId = line.id;
        lineId = line.id;
      }
    }
    if (requestData.loanId) {
      const loan = await service.getLoan(requestData.loanId);
      if (!loan) {
        validations.push({
          message: 'Loan not found'
        });
      } else {
        requestData.loanId = loan.id;
        loanId = loan.id;
      }
    }
    // console.log('requestValidation')
    // console.log(requestValidation, validateDate(requestData.date))
    if (requestData.date && !validateDate(requestData.date)) {
      validations.push({
        message: '"date" format is incorrect the correct format is YYYY-MM-DD HH:MM:SS'
      })
    }
    // const disbursementExists = await service.getDisbursementByPanNumber(requestData.panNumber);
    // if (disbursementExists && disbursementExists.id) {
    //   validations.push({
    //     message: `Disbursement with ${requestData.panNumber} already exists`
    //   });
    // }
    if (requestData.borrowerId && borrowerId === null) {
      validations.push({
        message: `Disbursement borrowerId not exists`
      });
    }
    if (requestData.lineId && lineId === null) {
      validations.push({
        message: `Disbursement lineId not exists`
      });
    }
    if (requestData.loanId && loanId === null) {
      validations.push({
        message: `Disbursement loanId not exists`
      });
    }
    if (requestValidation.error) {
      const finalRemark = requestValidation.error.details.concat(validations);
      await service.createDisbursementProcessingData(requestData, finalRemark);
      return responses.badRequestResponse(res, null, "Validation failed!", finalRemark);
    }
    if (validations.length) {
      await service.createDisbursementProcessingData(requestData, validations);
      return responses.badRequestResponse(res, null, "Validation failed!", validations);
    }
    await service.createDisbursementProcessingData(requestData, [{ message: 'Disbursement successfully created.' }]);
    const uuid = uuidv4.v4();
    requestData.uuid = uuid;
    const disbursement = await service.createDisbursement(requestData);
    // console.log('disbursement.toJSON()')
    // console.log(disbursement.toJSON())
    return responses.successResponse(res, disbursement.toJSON().id, null, "Disbursement Created Successfully!");
  } catch (error) {
    console.log(`${TAG}.addDisbursement.error: `, error)
    return responses.badRequestResponse(res, null, error["message"]);
  }
};

const getListDisbursements = async (req, res) => {};

const getById = async (req, res) => {};

const disbursementSearch = async (req, res) => {};

const updateDisbursement = async (req, res) => {};

const removeDisbursement = async (req, res) => {};

module.exports = {
  addDisbursement,
  getListDisbursements,
  getById,
  disbursementSearch,
  updateDisbursement,
  removeDisbursement
};
