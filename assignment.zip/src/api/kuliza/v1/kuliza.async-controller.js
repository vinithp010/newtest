const { v4: uuidv4 } = require("uuid");
const async = require("async");
const responses = require("../../../helpers/api-response/response.function");
const service = require("./kuliza.async-service");
const { convertExcelToJson } = require("../../../helpers/sheet.helper");
const documentSchemas = require("./kuliza.validation");

const { convertToStandardFormat } = require("../../../helpers/utils.helper");

const TAG = "kuliza.async-controller";

async function processBatch(batch, fileUniqueId, product, lmsToken, breToken, shouldRun = true) {
  await Promise.all(
    batch.map(async (batchData) => {
      if (shouldRun) {
        // shouldRun = false;

        if (!batchData.dataValues["validationResponse"]) {
          await service.processUpload(lmsToken, breToken, batchData.dataValues, product, fileUniqueId);
        }
      }
    })
  );
}

const uploadMasterSheet = async (req, res) => {
  // step: 1 -> insert record into database
  // step: 2 -> unique partnerLoanId check, validation check
  // step: 3 -> process upload

  let records = convertExcelToJson(req.file.path, true);
  // console.log("uploadMasterSheet: ", req.body);

  if (records !== null && records !== undefined && records.length > 0) {
    const fileUniqueId = uuidv4();
    const breResponse = await service.loginToBre();

    if (breResponse == null || breResponse == undefined || breResponse.status !== "OK") {
      return responses.badRequestResponse(res, null, breResponse, "Couldn't authenticate BRE!");
    }

    // fetch query for our own system
    const product = await service.findProduct(req.body.partnerId, req.body.productId);
    console.log(product);

    const shouldRun = true; // for test purpose only; and to run only one row from sheet
    const shouldValidate = true; // for test purpose only;

    let validationFailures = [];
    let insertableRecords = [];
    let processableRecords = [];

    const pLoanIds = [];

    records = records.map((record) => {
      // deleted for logging purpose as it consumes lines....please disable before release
      // delete record.repaymentJson;

      // console.log(`uploadMasterSheet.record.${record.partnerLoanId}: `, record);
      pLoanIds.push(record.partnerLoanId);
      record.poaNumber = "" + record.poaNumber; // convert numbers to string

      const validationResult = documentSchemas.mandatoryValidationSchema.validate(record, {
        abortEarly: false
      });

      if (!record.firstName) {
        let nameInData = ["", ""];
        if (record.fullName.includes("_")) nameInData = record.fullName.split("_");
        if (record.fullName.includes(" ")) nameInData = record.fullName.split(" ");
        record.firstName = nameInData[0];
        record.lastName = record.fullName.substring(`${nameInData[0]} `.length);
      }

      // modify record dates as per table validation
      record.repaymentJson = JSON.stringify(record.repaymentJson);
      record.installmentsOrTenor = record.installmentsOrTenor ? record.installmentsOrTenor : 0;
      record.applicationDate = convertToStandardFormat(record.applicationDate, true);
      record.dob = convertToStandardFormat(record.dob, false, "dob");
      record.coApplicantDob = convertToStandardFormat(record.coApplicantDob, false, "coApplicantDob");
      record.activationDate = convertToStandardFormat(record.activationDate, true);
      record.submittedOnDate = convertToStandardFormat(record.submittedOnDate, true);
      record.expectedDisbursementDate = convertToStandardFormat(record.expectedDisbursementDate, true);
      record.approvedOnDate = convertToStandardFormat(record.approvedOnDate, true);
      record.actualDisbursementDate = convertToStandardFormat(record.actualDisbursementDate, true);
      record.fileUniqueId = fileUniqueId;

      if (validationResult.error) {
        record["processFailure"] = "validationResponse";
        record["validationResponse"] = JSON.stringify(validationResult.error);
        validationFailures.push(validationResult.error);
      } else {
        insertableRecords.push(record);
      }

      return record;
    });

    console.table(records);
    const insertResult = await service.addToProcessor(insertableRecords);
    const loanCountResult = await service.findLoanIdCount(pLoanIds);
    console.table(loanCountResult);

    insertResult.forEach(async (insert) => {
      const loanIdCountRes = loanCountResult.find((loanId) => {
        return loanId.partnerLoanId == insert.dataValues.partnerLoanId;
      });

      if (loanIdCountRes.totalRecords > 1) {
        await service.markAsDuplicateRecord(insert.dataValues.id);
      }

      if (loanIdCountRes.totalRecords <= 1 && !insert.dataValues.validationResponse) {
        processableRecords.push(insert);
      }
    });

    const batches = [];
    while (processableRecords.length) {
      let batchRecords = processableRecords.splice(0, 35);
      batches.push(
        async () =>
          await processBatch(
            batchRecords,
            fileUniqueId,
            product,
            req.body.access_token,
            breResponse.data.access_token,
            shouldRun,
            shouldValidate
          )
      );
    }

    async.series(batches, async function (cbResult, cbError) {
      // only insert the not-null validation failures
      let resultFromDb = await service.getUploadResult(fileUniqueId);
      let result = {
        totalRecords: records.length,
        validationPassed: resultFromDb["validationPassed"],
        loanCreated: resultFromDb["loanCreated"],
        fullyProcessed: resultFromDb["fullyProcessed"],
        validationFailures: [...resultFromDb["validationFailures"], ...validationFailures],
        failures: resultFromDb["failures"],
        successes: resultFromDb["successes"],
        report: await service.generateUploadResultSheet(fileUniqueId)
      };
      console.log(result);

      return responses.successResponse(res, fileUniqueId, result, "Master sheet has been processed.");
    });
  } else return responses.badRequestResponse(res, null, null, "No records found!");
};

const getSheets = async (req, res) =>
  responses.successResponse(res, null, await service.getAllUploads(), "Master sheets fetched!");

const getSheetStatus = async (req, res) =>
  responses.successResponse(
    res,
    null,
    await service.generateUploadResultSheet(req.params.fileUniqueid),
    "Sheet status fetched!"
  );

module.exports = {
  uploadMasterSheet,
  getSheets,
  getSheetStatus
};
