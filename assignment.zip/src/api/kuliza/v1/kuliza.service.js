const axios = require("axios").default;
const { Sequelize } = require("./../../../../database/models/index");
const db = require("./../../../../database/models/index");
const { KULIZA_BASE_URL, APPEND_BRE_PORTAL, APPEND_LMS_PORTAL, KULIZA_MASTER_CONFIG } = require("./kuliza.config");

const TAG = "kuliza.service";

const { TFeederSheet } = db;
const { TPartner } = db;
const { TProduct } = db;

const LMS_URL = KULIZA_BASE_URL + APPEND_LMS_PORTAL;
const BRE_URL = KULIZA_BASE_URL + APPEND_BRE_PORTAL;

function getSheetUploadStatus(fileUniqueId, callback) {
  try {
    TFeederSheet.count({
      where: {
        fileUniqueId: fileUniqueId
      }
    })
      .then((total) => {
        TFeederSheet.count({
          where: { fileUniqueId: fileUniqueId, isProcessSuccess: true }
        }).then((success) => {
          TFeederSheet.findAll({
            attributes: [
              "id",
              "personalPanNumber",
              "processFailure",
              "kulizaBREResponse",
              "userCreationResponse",
              "loanCreationResponse",
              "loanApproveResponse",
              "loanDisbursementResponse",
              "repaymentResponse"
            ],
            where: { fileUniqueId: fileUniqueId, isProcessSuccess: false }
          }).then((failures) => {
            callback(null, {
              totalRecords: total,
              successfullyUploaded: success,
              failedToUpload: result - success,
              failures
            });
          });
        });
      })
      .catch((error) => callback(error, null));
  } catch (error) {
    callback(error, null);
  }
}

function downloadSheetUploadStatus(fileUniqueId, callback) {
  try {
    TFeederSheet.findAll({
      attributes: {
        exclude: [
          "id",
          "fileUniqueId",
          "createdBy",
          "updatedBy",
          "processFailure",
          "createdAt",
          "updatedAt",
          "text0",
          "text1",
          "text2",
          "text3",
          "text4",
          "numeric0",
          "numeric1",
          "numeric2",
          "numeric3",
          "numeric4",
          "date0",
          "date1",
          "date2",
          "date3",
          "date4",
          "boolean0",
          "boolean1",
          "boolean2",
          "boolean3",
          "boolean4"
        ]
      },
      where: {
        fileUniqueId: fileUniqueId
      },
      raw: true
    }).then((total) => {
      callback(null, total);
    });
  } catch (error) {
    callback(error, null);
  }
}

function getUploadSheetList(callback) {
  TFeederSheet.findAll({
    attributes: [
      ["fileUniqueId", "fileUniqueId"],
      [Sequelize.fn("count", Sequelize.col("id")), "totalRecords"]
    ],
    where: {},
    group: ["fileUniqueId"],
    raw: true
  })
    .then((total) => {
      callback(null, total);
    })
    .catch((error) => {
      callback(error, null);
    });
}

function addToKulizaProcessorAsync(data) {
  return TFeederSheet.create({
    uuid: null,
    uploadData: JSON.stringify(data)
  });
}

async function processKulizaRequest(token, data, productId, fileUniqueId) {
  addToKulizaProcessor(
    {
      ...data,
      fileUniqueId
    },
    (error1, result1) => {
      if (error1) {
        console.log(`${TAG}.addToKulizaProcessor.error: `, error1);
        return;
      }

      console.log(`${TAG}.addToKulizaProcessor.result: `, result1.dataValues);
      validateFromBRE(
        token,
        data,
        (error2, result2) => {
          if (error2) {
            // console.log(`${TAG}.validateFromBRE.error: `, error2);
            updateApiResultToProcessor(result1.dataValues.id, "kulizaBREResponse", error2);
            // return;
          }

          updateApiResultToProcessor(result1.dataValues.id, "kulizaBREResponse", result2);
          createClient(
            token,
            data,
            (error3, result3) => {
              if (error3) {
                // console.log(`${TAG}.createClient.error: `, error3);
                updateApiResultToProcessor(result1.dataValues.id, "userCreationResponse", error3);
                // return;
              }

              updateApiResultToProcessor(result1.dataValues.id, "userCreationResponse", result3);
              createLoan(
                token,
                data,
                (error4, result4) => {
                  if (error4) {
                    // console.log(`${TAG}.createLoan.error: `, error4);
                    updateApiResultToProcessor(result1.dataValues.id, "loanCreationResponse", error4);
                    // return;
                  }

                  updateApiResultToProcessor(result1.dataValues.id, "loanCreationResponse", result4);
                  approveLoan(
                    token,
                    data,
                    (error5, result5) => {
                      if (error5) {
                        // console.log(`${TAG}.approveLoan.error: `, error5);
                        updateApiResultToProcessor(result1.dataValues.id, "loanApproveResponse", error5);
                        // return;
                      }

                      updateApiResultToProcessor(result1.dataValues.id, "loanApproveResponse", result5);
                      createDisbursement(
                        token,
                        data,
                        (error6, result6) => {
                          if (error6) {
                            // console.log(`${TAG}.createDisbursement.error: `, error6);
                            updateApiResultToProcessor(result1.dataValues.id, "loanDisbursementResponse", error6);
                            // return;
                          }

                          updateApiResultToProcessor(result1.dataValues.id, "loanDisbursementResponse", result6);
                          makeRepayment(
                            token,
                            data,
                            (error7, result7) => {
                              if (error4) {
                                // console.log(`${TAG}.makeRepayment.error: `, error7);
                                updateApiResultToProcessor(result1.dataValues.id, "repaymentResponse", error7);
                                // return;
                              }

                              updateApiResultToProcessor(result1.dataValues.id, "repaymentResponse", result7);
                            },
                            {}
                          );
                        },
                        {}
                      );
                    },
                    {}
                  );
                },
                {}
              );
            },
            {}
          );
        },
        {
          productId
        }
      );
    }
  );
}

function addToKulizaProcessor(data, callback, isBulk = false) {
  TFeederSheet.create({
    ...data
  })
    .then((result) => {
      // result.uploadData = JSON.parse(result.uploadData);
      callback(null, result);
    })
    .catch((error) => callback(error, null));
}

function validateFromBRE(token, data, callback, addOnData = {}) {
  const requestData = {};
  Object.keys(data).forEach((key) => {
    const masterConfig = KULIZA_MASTER_CONFIG[key];
    requestData[`${masterConfig.breKey || masterConfig.key}-${masterConfig.type}`] = data[masterConfig.key];
  });
  // console.log(`${TAG}.validateFromBRE.requestData: `, requestData);
  delete requestData[KULIZA_MASTER_CONFIG.repaymentJson.key];

  makeApiCallInAxios(
    BRE_URL,
    token,
    {
      inputData: {
        ...requestData
      },
      productIds: [addOnData.productId]
    },
    callback
  );
}

function createClient(token, data, callback, addOnData = {}) {
  makeApiCallInAxios(
    `${LMS_URL}/client/create-service-request`,
    token,
    {
      // mandatory fields
      actionableContext_firstName: data[KULIZA_MASTER_CONFIG.firstName.key] || null,
      actionableContext_lastName: data[KULIZA_MASTER_CONFIG.lastName.key] || null,
      actionableContext_dateOfBirth: data[KULIZA_MASTER_CONFIG.dob.key] || null,
      actionableContext_submittedOnDate: data[KULIZA_MASTER_CONFIG.applicationDate.key] || null,
      actionableContext_activationDate: data[[KULIZA_MASTER_CONFIG.applicationDate.key]] || null,
      //optional fields
      actionableContext_permPincode: data[KULIZA_MASTER_CONFIG.residentialPinCode.key] || null,
      actionableContext_permState: data[KULIZA_MASTER_CONFIG.residentialState.key] || null,
      actionableContext_gender: data[KULIZA_MASTER_CONFIG.gender.key] || null,
      actionableContext_pan: data[KULIZA_MASTER_CONFIG.personalPanNumber.key] || null,
      actionableContext_currCountry: data[KULIZA_MASTER_CONFIG.actionableContext_currCountry.key] || null,
      actionableContext_alternateMobileNumber:
        data[KULIZA_MASTER_CONFIG.actionableContext_alternateMobileNumber.key] || null,
      actionableContext_permAddressLine2: data[KULIZA_MASTER_CONFIG.actionableContext_permAddressLine2.key] || null,
      actionableContext_permAddressLine1: data[KULIZA_MASTER_CONFIG.permanentAddress.key] || null,
      actionableContext_mobileNumber: data[KULIZA_MASTER_CONFIG.mobileNumber.key] || null,
      actionableContext_currState: data.actionableContext_currState || null,
      actionableContext_aadhar: data[KULIZA_MASTER_CONFIG.aadharNumber.key] || null,
      actionableContext_permCountry: data.actionableContext_permCountry || null,
      actionableContext_currPincode: data[KULIZA_MASTER_CONFIG.businessPinCode.key] || null,
      actionableContext_permCity: data[KULIZA_MASTER_CONFIG.residentialCity.key] || null,
      actionableContext_currCity: data[KULIZA_MASTER_CONFIG.businessCity.key] || null,
      actionableContext_currAddressLine2: data.actionableContext_currAddressLine2 || null,
      actionableContext_permSameCurr: data.actionableContext_permSameCurr || null,
      actionableContext_currAddressLine1: data[KULIZA_MASTER_CONFIG.businessAddress.key] || null,
      actionableContext_email: data[KULIZA_MASTER_CONFIG.emailId.key] || null,
      // targetContext keys
      targetContext_processDefinitionKey: "adminMaker__createClient03",
      targetContext_officeId: data[KULIZA_MASTER_CONFIG.targetContext_officeId.key] || "kolkata"
    },
    callback
  );
}

function createLoan(token, data, callback, addOnData = {}) {
  makeApiCallInAxios(
    `${LMS_URL}/client/create-service-request`,
    token,
    {
      // mandatory fields
      actionableContext_allowPartialPeriodInterestCalcualtion:
        data[KULIZA_MASTER_CONFIG.actionableContext_allowPartialPeriodInterestCalcualtion.key] || false,
      actionableContext_amortizationType: data[KULIZA_MASTER_CONFIG.actionableContext_amortizationType.key] || 1,
      actionableContext_chargesTable: data[KULIZA_MASTER_CONFIG.actionableContext_chargesTable.key] || [],
      actionableContext_disbursementData: data[KULIZA_MASTER_CONFIG.actionableContext_disbursementData.key] || [],
      actionableContext_expectedDisbursementDate:
        data[KULIZA_MASTER_CONFIG.actionableContext_expectedDisbursementDate.key] || null,
      actionableContext_interestCalculationPeriodType:
        data[KULIZA_MASTER_CONFIG.actionableContext_interestCalculationPeriodType.key] || 0,
      actionableContext_interestRatePerPeriod: data[KULIZA_MASTER_CONFIG.interestRateMonhtly.key] || null,
      actionableContext_interestType: data[KULIZA_MASTER_CONFIG.actionableContext_interestType.key] || 0,
      actionableContext_isEqualAmortization:
        data[KULIZA_MASTER_CONFIG.actionableContext_isEqualAmortization.key] || false,
      actionableContext_loanTermFrequency: data[KULIZA_MASTER_CONFIG.actionableContext_loanTermFrequency.key] || null,
      actionableContext_loanTermFrequencyType:
        data[KULIZA_MASTER_CONFIG.actionableContext_loanTermFrequencyType.key] || 2,
      actionableContext_loanType: data[KULIZA_MASTER_CONFIG.actionableContext_loanType.key] || "individual",
      actionableContext_numberOfRepayments: data[KULIZA_MASTER_CONFIG.repaymentJson.key].length || null,
      actionableContext_principal: data[KULIZA_MASTER_CONFIG.loanAmount.key] || null,
      actionableContext_raisedOn: data[KULIZA_MASTER_CONFIG.actionableContext_raisedOn.key] || null,
      actionableContext_repaymentEvery: data[KULIZA_MASTER_CONFIG.actionableContext_repaymentEvery.key] || null,
      actionableContext_repaymentFrequencyType:
        data[KULIZA_MASTER_CONFIG.actionableContext_repaymentFrequencyType.key] || 2,
      actionableContext_requestRelatedTo:
        data[KULIZA_MASTER_CONFIG.actionableContext_requestRelatedTo.key] || "Create Loan",
      actionableContext_submittedOnDate: data[KULIZA_MASTER_CONFIG.actionableContext_submittedOnDate.key] || null,
      actionableContext_transactionProcessingStrategyId:
        data[KULIZA_MASTER_CONFIG.actionableContext_transactionProcessingStrategyId.key] || 6,
      // optional fields
      actionableContext_graceOnArrearsAgeing:
        data[KULIZA_MASTER_CONFIG.actionableContext_graceOnArrearsAgeing.key] || null,
      actionableContext_graceOnInterestCharged:
        data[KULIZA_MASTER_CONFIG.actionableContext_graceOnInterestCharged.key] || null,
      actionableContext_graceOnInterestPayment:
        data[KULIZA_MASTER_CONFIG.actionableContext_graceOnInterestPayment.key] || null,
      actionableContext_graceOnPrincipalPayment:
        data[KULIZA_MASTER_CONFIG.actionableContext_graceOnPrincipalPayment.key] || null,
      actionableContext_inArrearsTolerance: data[KULIZA_MASTER_CONFIG.actionableContext_inArrearsTolerance.key] || null,
      actionableContext_maxOutstandingLoanBalance:
        data[KULIZA_MASTER_CONFIG.actionableContext_maxOutstandingLoanBalance.key] || null,
      actionableContext_numberOfAmortizationRepayments:
        data[KULIZA_MASTER_CONFIG.actionableContext_numberOfAmortizationRepayments.key] || null,
      actionableContext_repaymentsStartingFromDate: data[KULIZA_MASTER_CONFIG.firstRepaymentDate.key] || null,
      actionableContext_stepIntervals: data.actionableContext_stepIntervals || null,
      // targetContext keys
      targetContext_clientNumber: data[KULIZA_MASTER_CONFIG.targetContext_clientNumber.key] || null,
      targetContext_processDefinitionKey: "adminMaker__createLoan02",
      targetContext_productId: data[KULIZA_MASTER_CONFIG.targetContext_productId.key] || null
    },
    callback
  );
}

function approveLoan(token, data, callback, addOnData = {}) {
  makeApiCallInAxios(
    `${LMS_URL}/loan/create-service-request`,
    token,
    {
      // targetContext keys
      targetContext_clientNumber: data[KULIZA_MASTER_CONFIG.targetContext_clientNumber.key] || null,
      targetContext_loanNumber: data[KULIZA_MASTER_CONFIG.targetContext_loanNumber.key] || null,
      targetContext_processDefinitionKey: "adminMaker__approveLoan01",
      // optional fields
      // mandatory fields
      actionableContext_approvedOnDate: data.actionableContext_approvedOnDate || null,
      actionableContext_approvedLoanAmount: data[KULIZA_MASTER_CONFIG.approvedAmount.key] || null,
      actionableContext_expectedDisbursementDate:
        data[KULIZA_MASTER_CONFIG.actionableContext_expectedDisbursementDate.key] || null,
      actionableContext_disbursementData: data[KULIZA_MASTER_CONFIG.actionableContext_disbursementData.key] || [],
      actionableContext_isTransactional: data[KULIZA_MASTER_CONFIG.actionableContext_isTransactional.key] || false
    },
    callback
  );
}

function createDisbursement(token, data, callback, addOnData = {}) {
  makeApiCallInAxios(
    `${LMS_URL}/loan/create-service-request`,
    token,
    {
      // mandatory fields

      // optional fields
      actionableContext_actualDisbursementDate: data.actionableContext_actualDisbursementDate || "28 Apr 2022",
      actionableContext_transactionAmount: data.actionableContext_transactionAmount || "35000",
      actionableContext_isTransactional: data.actionableContext_isTransactional || "true",
      actionableContext_paymentTypeId: data.actionableContext_paymentTypeId || "bankTransfer01",
      actionableContext_paymentTypeId2: data.actionableContext_paymentTypeId2 || "bankTransfer01",
      // targetContext keys
      targetContext_clientNumber: data.targetContext_clientNumber || "000000033",
      targetContext_loanNumber: data.targetContext_loanNumber || "000000031",
      targetContext_processDefinitionKey: "adminMaker__disburseLoan01",
      targetContext_requestType: "disburse"
    },
    callback
  );
}

function makeRepayment(token, data, callback, addOnData = {}) {
  makeApiCallInAxios(
    `${LMS_URL}/loan/create-service-request`,
    token,
    {
      // mandatory fields

      // optional fields
      actionableContext_transactionDate: data.actionableContext_transactionDate || "28 April 2022",
      actionableContext_paymentTypeId: data.actionableContext_paymentTypeId || "bankTransfer01",
      actionableContext_paymentTypeId2: data.actionableContext_paymentTypeId2 || "bankTransfer01",
      actionableContext_transactionAmount: data.actionableContext_transactionAmount || "2000",
      actionableContext_applyCharge: data.actionableContext_applyCharge || "noCharge",
      actionableContext_requestRelatedTo: data.actionableContext_requestRelatedTo || "Make Repayment",
      actionableContext_repaymentMode: data.actionableContext_repaymentMode || "28 Apr 2022",
      actionableContext_isTransactional: data.actionableContext_isTransactional || "true",
      actionableContext_raisedOn: data.actionableContext_raisedOn || "28 April 2022",
      actionableContext_instrumentType: data.actionableContext_instrumentType || "NACH",
      // targetContext keys
      targetContext_clientNumber: data.targetContext_clientNumber,
      targetContext_loanNumber: data.targetContext_loanNumber,
      targetContext_processDefinitionKey: "adminMaker__makeRepayment01",
      targetContext_requestType: "repayment"
    },
    callback
  );
}

function updateApiResultToProcessor(identifier, column, result, callback) {
  const query = {};
  query[column] = JSON.stringify(result);

  TFeederSheet.update(query, {
    where: {
      id: identifier
    }
  })
    .then((result) => {
      console.log(`${TAG}.${arguments.callee.name}.updateApiResultToProcessor: `, result);
      if (callback) callback(null, result);
    })
    .catch((error) => {
      console.log(`${TAG}.${arguments.callee.name}.updateApiResultToProcessor: `, error);
      if (callback) callback(error, null);
    });
}

function makeApiCallInAxios(url, token, body, callback) {
  console.log(`${TAG}.makeApiCallInAxios: `, token);
  axios
    .post(url, body, {
      headers: {
        authorization: `Bearer ${token}`
      }
    })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function addPartner(data, callback) {
  TPartner.create(data)
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getPartners(callback) {
  TPartner.findAll()
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function addProduct(data, callback) {
  TProduct.create(data)
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function updateProduct(data, callback) {
  const query = {};
  for (const key in data) {
    if (key !== 'id') query[key] = data[key];
  }
  TProduct.update(query, {
    where: {
      id: data.id
    }
  })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getProducts(callback) {
  TProduct.findAll()
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getDetailedProducts(callback) {
  TProduct.findAll({
    include: [
      {
        model: TPartner,
        as: "partner"
      }
    ]
  })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

async function getUploadList(pageSize, page, callback) {
  const limit = pageSize ? pageSize : 10;
  const offset = page && page > 0 ? (page - 1) * limit : 0;
  try {
    const data = await TFeederSheet.findAll({
      attributes: ["id", "personalPanNumber", "aadharNumber", "fullName", "mobileNumber", "emailId"],
      where: {},
      order: [["createdAt", "DESC"]],
      limit: parseInt(limit) || 10,
      offset: parseInt(offset) || 0,
      raw: true
    });
    const totalRecords = await TFeederSheet.count({
      where: {}
    });
    callback(null, { data, totalRecords, page, pageSize });
  } catch (error) {
    callback(error, null);
  }
}

function getUploadDetails(id, callback) {
  TFeederSheet.findByPk(id, { raw: true })
    .then((detail) => {
      callback(null, detail);
    })
    .catch((error) => {
      callback(error, null);
    });
}

function getDetailedPartners(callback) {
  TPartner.findAll({
    attributes: ["id", "partnerName"],
    include: [
      {
        model: TProduct,
        as: "product",
        attributes: ["id", "name", "breId"]
      }
    ]
  })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

module.exports = {
  addToKulizaProcessorAsync,
  getSheetUploadStatus,
  processKulizaRequest,
  addToKulizaProcessor,
  downloadSheetUploadStatus,
  getUploadSheetList,
  getUploadList,
  getUploadDetails,

  addPartner,
  getPartners,
  addProduct,
  updateProduct,
  getProducts,
  getDetailedProducts,
  getDetailedPartners
};
