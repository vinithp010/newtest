const { getLMSConfig } = require("../../../../configs/env.config");

const lmsBaseUrl = getLMSConfig().LMS_URL;

// const lendingLoginCreds = {
//   email: "adminmaker@arthmate.com",
//   password: "Blueskymaker*007"
// };
const lendingLoginCreds = getLMSConfig().LMS_LENDING_CREDS;
const lendingLoginApi = "/configurator/product/auth/login";
const lendingUploadApi = `/lms-portal-service/lendin/portal/${getLMSConfig().LMS_EXT_ROLE_ID}`;

// const breCreds = {
//   email: "ce-user@kuliza.com",
//   password: "Kuliza@123"
// };
const breCreds = getLMSConfig().LMS_BRE_CREDS;
const breLoginApi = "/configurator/product/auth/login";
const breValidationApi = "/configurator/product/api/test/fire-rules";

// const productCreds = {
//   username: "Administrator",
//   password: "Z29vZG1vcm5pbmc"
// };
const productCreds = getLMSConfig().LMS_PRODUCT_CREDS;
const productHeader = {
  "Fineract-Platform-TenantId": getLMSConfig().LMS_PRODUCT_HEADER
};
const productLoginApi = `/lms-core/api/oauth/token?client_id=lms-configurator&client_secret=4496&grant_type=password&password=${productCreds.password}&username=${productCreds.username}`;
const productProductApi = "/lms-core/api/v1/loanproducts";

const createClientRequest = {
  mandatroies: {
    actionableContext_firstName: "actionableContext_firstName",
    actionableContext_lastName: "actionableContext_lastName",
    actionableContext_dateOfBirth: "actionableContext_dateOfBirth",
    actionableContext_submittedOnDate: "actionableContext_submittedOnDate",
    actionableContext_activationDate: "actionableContext_activationDate"
  },
  optionals: {
    actionableContext_gender: "actionableContext_gender",
    actionableContext_pan: "actionableContext_pan",
    actionableContext_aadhar: "actionableContext_aadhar",
    actionableContext_email: "actionableContext_email",
    actionableContext_mobileNumber: "actionableContext_mobileNumber",
    actionableContext_alternateMobileNumber: "actionableContext_alternateMobileNumber",
    actionableContext_currAddressLine1: "actionableContext_currAddressLine1",
    actionableContext_currAddressLine2: "actionableContext_currAddressLine2",
    actionableContext_currPincode: "actionableContext_currPincode",
    actionableContext_currCity: "actionableContext_currCity",
    actionableContext_currState: "actionableContext_currState",
    actionableContext_currCountry: "actionableContext_currCountry",
    actionableContext_permAddressLine1: "actionableContext_permAddressLine1",
    actionableContext_permAddressLine2: "actionableContext_permAddressLine2",
    actionableContext_permCity: "actionableContext_permCity",
    actionableContext_permState: "actionableContext_permState",
    actionableContext_permCountry: "actionableContext_permCountry",
    actionableContext_permPincode: "actionableContext_permPincode",
    actionableContext_permSameCurr: "actionableContext_permSameCurr"
  },
  hardCodeds: { targetContext_processDefinitionKey: "adminMaker__createClient03", targetContext_officeId: "kolkata" },
  dependents: {}
};

const createLoanRequest = {
  mandatroies: {
    actionableContext_submittedOnDate: "actionableContext_submittedOnDate",
    actionableContext_expectedDisbursementDate: "actionableContext_expectedDisbursementDate",
    actionableContext_allowPartialPeriodInterestCalcualtion: "actionableContext_allowPartialPeriodInterestCalcualtion",
    actionableContext_principal: "actionableContext_principal",
    actionableContext_interestRatePerPeriod: "actionableContext_interestRatePerPeriod",
    actionableContext_numberOfRepayments: "actionableContext_numberOfRepayments",
    actionableContext_repaymentEvery: "actionableContext_repaymentEvery",
    actionableContext_repaymentFrequencyType: "actionableContext_repaymentFrequencyType",
    actionableContext_loanTermFrequency: "actionableContext_loanTermFrequency",
    actionableContext_loanTermFrequencyType: "actionableContext_loanTermFrequencyType",
    actionableContext_amortizationType: "actionableContext_amortizationType",
    actionableContext_interestCalculationPeriodType: "actionableContext_interestCalculationPeriodType",
    actionableContext_interestType: "actionableContext_interestType",
    actionableContext_transactionProcessingStrategyId: "actionableContext_transactionProcessingStrategyId",
    actionableContext_chargesTable: "actionableContext_chargesTable",
    actionableContext_disbursementData: "actionableContext_disbursementData",
    actionableContext_isEqualAmortization: "actionableContext_isEqualAmortization",
    actionableContext_raisedOn: "actionableContext_raisedOn"
  },
  optionals: {
    actionableContext_repaymentsStartingFromDate: "actionableContext_repaymentsStartingFromDate",
    actionableContext_graceOnArrearsAgeing: "actionableContext_graceOnArrearsAgeing",
    actionableContext_graceOnInterestCharged: "actionableContext_graceOnInterestCharged",
    actionableContext_graceOnInterestPayment: "actionableContext_graceOnInterestPayment",
    actionableContext_graceOnPrincipalPayment: "actionableContext_graceOnPrincipalPayment",
    actionableContext_inArrearsTolerance: "actionableContext_inArrearsTolerance",
    actionableContext_maxOutstandingLoanBalance: "actionableContext_maxOutstandingLoanBalance",
    actionableContext_numberOfAmortizationRepayments: "actionableContext_numberOfAmortizationRepayments",
    actionableContext_stepIntervals: "actionableContext_stepIntervals"
  },
  hardCodeds: {
    actionableContext_requestRelatedTo: "Create Loan",
    actionableContext_loanType: "individual",
    targetContext_processDefinitionKey: "adminMaker__createLoan02"
  },
  dependents: {
    targetContext_productId: "targetContext_productId",
    targetContext_clientNumber: "targetContext_clientNumber"
  }
};

const approveLoanRequest = {
  mandatroies: {
    actionableContext_approvedOnDate: "actionableContext_approvedOnDate",
    actionableContext_approvedLoanAmount: "actionableContext_approvedLoanAmount",
    actionableContext_expectedDisbursementDate: "actionableContext_expectedDisbursementDate",
    actionableContext_disbursementData: "actionableContext_disbursementData"
  },
  optionals: {},
  hardCodeds: {
    actionableContext_isTransactional: false,
    targetContext_processDefinitionKey: "adminMaker__approveLoan01"
  },
  dependents: {
    targetContext_clientNumber: "targetContext_clientNumber",
    targetContext_loanNumber: "targetContext_loanNumber"
  }
};

const createDisbursementRequest = {
  mandatroies: {
    actionableContext_actualDisbursementDate: "actionableContext_actualDisbursementDate",
    actionableContext_transactionAmount: "actionableContext_transactionAmount"
  },
  optionals: {},
  hardCodeds: {
    actionableContext_isTransactional: false,
    actionableContext_paymentTypeId: "Bank Transfer",
    actionableContext_paymentTypeId2: null,
    targetContext_processDefinitionKey: "adminMaker__disburseLoan01",
    targetContext_requestType: "disburse"
  },
  dependents: {
    targetContext_clientNumber: "targetContext_clientNumber",
    targetContext_loanNumber: "targetContext_loanNumber"
  }
};

const makeRepaymentRequest = {
  mandatroies: {
    actionableContext_transactionDate: "actionableContext_transactionDate",
    actionableContext_transactionAmount: "actionableContext_transactionAmount",
    actionableContext_applyCharge: "actionableContext_applyCharge",
    actionableContext_repaymentMode: "actionableContext_repaymentMode",
    actionableContext_raisedOn: "actionableContext_raisedOn"
  },
  optionals: {},
  hardCodeds: {
    actionableContext_requestRelatedTo: "Make Repayment",
    actionableContext_paymentTypeId: "Bank Transfer",
    actionableContext_paymentTypeId2: null,
    actionableContext_isTransactional: false,
    actionableContext_instrumentType: null,
    targetContext_processDefinitionKey: "adminMaker__makeRepayment01",
    targetContext_requestType: "repayment"
  },
  dependents: {
    targetContext_clientNumber: "targetContext_clientNumber",
    targetContext_loanNumber: "targetContext_loanNumber"
  }
};

module.exports = {
  BRE_LOGIN_URL: lmsBaseUrl + breLoginApi,
  BRE_VALIDATION_URL: lmsBaseUrl + breValidationApi,
  LMS_LENDING_URL: lmsBaseUrl + lendingUploadApi,
  LOS_LOGIN_URL: lmsBaseUrl + productLoginApi,
  LOS_PRODUCT_URL: lmsBaseUrl + productProductApi,

  BRE_LOGIN_CREDS: breCreds,
  LOS_LOGIN_CREDS: productCreds,
  LOS_PRODUCT_HEADER: productHeader,

  createClientRequest,
  createLoanRequest,
  approveLoanRequest,
  createDisbursementRequest,
  makeRepaymentRequest
};
