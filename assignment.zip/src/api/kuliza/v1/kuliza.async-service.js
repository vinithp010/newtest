const axios = require("axios").default;
const fs = require("fs");
const json2xls = require("json2xls");
const { convertToKulizaFormat, convertToStandardFormat } = require("../../../helpers/utils.helper");
const { Op } = require("sequelize");

const db = require("../../../../database/models/index");
const kulizaConfig = require("./kuliza.config");
const mapper = require("../../../../sheet-api-bre-mapping.json");

const TAG = "kuliza.async-service";

const { TFeederSheet } = db;
const { TProduct } = db;

async function findProduct(partnerId, productId) {
  console.log(`${TAG}.findProduct: `);
  return await TProduct.findOne({
    where: {
      id: productId,
      partnerId
    },
    raw: true
  });
}

async function getAllUploads() {
  console.log(`${TAG}.getAllUploads: `);
  return await TFeederSheet.findAll({
    attributes: [
      ["fileUniqueId", "fileUniqueId"],
      [db.Sequelize.fn("count", db.Sequelize.col("id")), "totalRecords"]
    ],
    where: {},
    group: ["fileUniqueId"],
    raw: true
  });
}

async function generateUploadResultSheet(fileUniqueId) {
  console.log(`${TAG}.generateUploadResultSheet: `);
  const result = await TFeederSheet.findAll({
    attributes: {
      exclude: ["id", "createdBy", "updatedBy", "processFailure", "createdAt", "updatedAt"]
    },
    where: {
      fileUniqueId
    },
    raw: true
  });

  const xls = json2xls(result);
  const filename = `${fileUniqueId}.xlsx`;
  const filePath = `${__dirname}/../../../../uploads/${filename}`;

  fs.writeFileSync(filePath, xls, "binary");

  return `${process.env.API_URL}/downloads/${filename}`;
}

async function processLMSResponse(identifier, column, result, success, optionals = {}) {
  console.log(`${TAG}.processLMSResponse: `, identifier);
  const query = { ...optionals };
  try {
    if (success) {
      query[column] = JSON.stringify(result);
      // query.isProcessSuccess = true;
    } else {
      query[column] = JSON.stringify(
        result || result.data || result.data.errors || result.errors || result.error || result.message
      );
      // query.isProcessSuccess = false;
      query.processFailure = column;
    }
  } catch (error) {
    query[column] = `${result}`;
    // query.isProcessSuccess = false;
    query.processFailure = column;
  }

  return await TFeederSheet.update(query, {
    where: {
      id: identifier
    }
  });
}

async function processFailure(response, rowId, column, message) {
  console.log(`${TAG}.processFailure: `);
  const failure = {
    ...response,
    process: message
  };
  await processLMSResponse(rowId, column, failure, false);
  return failure;
}

async function getUploadResult(fileUniqueId) {
  console.log(`${TAG}.getUploadResult: `);
  const totalRecords = await TFeederSheet.count({
    where: {
      fileUniqueId
    },
    raw: true
  });
  // const duplicateRecords = await TFeederSheet.findAll({
  //   attributes: ["id", "partnerLoanId", "validationResponse"],
  //   where: {
  //     fileUniqueId,
  //     uniqueIdFailure: 1
  //   },
  //   raw: true
  // });
  const validationPassed = await TFeederSheet.count({
    where: {
      fileUniqueId,
      validationResponse: null
    },
    raw: true
  });
  const loanCreated = await TFeederSheet.count({
    where: {
      fileUniqueId,
      isLoanCreated: true
    },
    raw: true
  });
  const fullyProcessed = await TFeederSheet.count({
    where: {
      fileUniqueId,
      isProcessSuccess: true
    },
    raw: true
  });
  const successes = await TFeederSheet.findAll({
    attributes: [
      "id",
      "personalPanNumber",
      "partnerLoanId",
      "processFailure",
      "uniqueIdFailure",
      "validationResponse",
      "kulizaBREResponse",
      "userCreationResponse",
      "loanCreationResponse",
      "isLoanCreated",
      "loanApproveResponse",
      "loanDisbursementResponse",
      "repaymentResponse"
    ],
    where: {
      fileUniqueId,
      isLoanCreated: true
    },
    raw: true
  });
  const validationFailures = await TFeederSheet.findAll({
    attributes: ["id", "partnerLoanId", "validationResponse"],
    where: {
      fileUniqueId,
      isProcessSuccess: false,
      validationResponse: { [Op.ne]: null }
    },
    raw: true
  });
  const failures = await TFeederSheet.findAll({
    attributes: [
      "id",
      "personalPanNumber",
      "partnerLoanId",
      "processFailure",
      "uniqueIdFailure",
      "validationResponse",
      "kulizaBREResponse",
      "userCreationResponse",
      "loanCreationResponse",
      "isLoanCreated",
      "loanApproveResponse",
      "loanDisbursementResponse",
      "repaymentResponse"
    ],
    where: {
      fileUniqueId,
      isProcessSuccess: false,
      validationResponse: { [Op.eq]: null }
    },
    raw: true
  });

  return {
    // totalRecords,
    validationPassed,
    loanCreated,
    fullyProcessed,
    successes,
    // duplicateRecords,
    validationFailures,
    failures
  };
}

async function updateLoanCreationFeederSheet(identifier) {
  console.log(`${TAG}.updateLoanCreationFeederSheet: `);
  const query = {
    isLoanCreated: true
  };
  return await TFeederSheet.update(query, {
    where: {
      id: identifier
    }
  });
}

async function updateValidationFeederSheet(identifier, validationRes) {
  console.log(`${TAG}.updatevalidationFeederSheet: `);
  const query = {
    validationResponse: validationRes
  };
  return await TFeederSheet.update(query, {
    where: {
      id: identifier
    }
  });
}

async function findLoanIdCount(loanIds) {
  console.log(`${TAG}.findLoanIdCount: `);

  const rawQuery = `WITH () AS pLoanId UPDATE ${TFeederSheet.name} SET 'uniqueIdFailure' = true WHERE 'partnerLoanId' = pLoanId AND (SELECT 'partnerLoanId', COUNT('partnerLoanId') WHERE 'partnerLoanId' IN ${loanIds}) > 1`;

  return await TFeederSheet.findAll({
    attributes: [
      ["partnerLoanId", "partnerLoanId"],
      [db.Sequelize.fn("count", db.Sequelize.col("partnerLoanId")), "totalRecords"]
    ],
    where: {
      partnerLoanId: { [Op.in]: loanIds }
    },
    group: ["partnerLoanId"],
    raw: true
  });
}

async function markAsDuplicateRecord(id) {
  console.log(`${TAG}.markAsDuplicateRecord: `);

  return await TFeederSheet.update(
    {
      uniqueIdFailure: true,
      validationResponse: "Duplicate Record",
      isProcessSuccess: false,
      processFailure: "validationResponse"
    },
    {
      where: {
        id: id
      }
    }
  );
}

async function addToProcessor(records) {
  console.log(`${TAG}.addToProcessor: `);
  return await TFeederSheet.bulkCreate(records, { returning: true, raw: true });
}

async function processUpload(lmsToken, breToken, tableRecord, product, fileUniqueId) {
  console.log(`${TAG}.processUpload: `, tableRecord.id);

  try {
    const sheetData = tableRecord;
    // delete sheetData.id;

    const resBreValidation = await validateFromBRE(breToken, sheetData, product);
    // console.log(`${TAG}.validateFromBRE.result: `, resBreValidation);
    await processLMSResponse(tableRecord.id, "kulizaBREResponse", resBreValidation, true);

    if (
      resBreValidation &&
      resBreValidation.status == 200 &&
      resBreValidation.data &&
      resBreValidation.data[0] &&
      resBreValidation.data[0].data &&
      resBreValidation.data[0].data.output &&
      resBreValidation.data[0].data.output.FtCash_UBL &&
      resBreValidation.data[0].data.output.FtCash_UBL === "Go"
    ) {
      const resCreateClient = await createClient(lmsToken, sheetData, {});
      // console.log(`${TAG}.createClient.result: `, resCreateClient);
      await processLMSResponse(tableRecord.id, "userCreationResponse", resCreateClient);

      if (resCreateClient.status == 200) {
        const resLosLogin = await loginToLos();
        // console.log(`${TAG}.loginToLos.result: `, resLosLogin);

        if (resLosLogin && resLosLogin.access_token) {
          const resLoanProduct = await getProductDetails(resLosLogin.access_token, product.loanProductId);
          // console.log(`${TAG}.getProductDetails.result: `, resLoanProduct ? resLoanProduct.charges : resLoanProduct);

          if (resLoanProduct) {
            const chargesOverride = [];
            if (resLoanProduct.charges) {
              resLoanProduct.charges.forEach((charge, index) => {
                Object.keys(sheetData).every((key) => {
                  // console.log(
                  //   "charges: ",
                  //   `${key.toLowerCase().replace(" ", "").replace("_", "")} - ${charge.name
                  //     .toLowerCase()
                  //     .replace(" ", "")
                  //     .replace("_", "")}`
                  // );
                  if (
                    key.toLowerCase().replaceAll(" ", "").replaceAll("_", "") ==
                    charge.name.toLowerCase().replaceAll(" ", "").replaceAll("_", "")
                  ) {
                    console.log(
                      "charges: ",
                      `${key.toLowerCase().replaceAll(" ", "").replaceAll("_", "")} - ${charge.name
                        .toLowerCase()
                        .replaceAll(" ", "")
                        .replaceAll("_", "")}`
                    );
                    if (sheetData[key]) {
                      resLoanProduct.charges[index].amount = sheetData[key];
                      chargesOverride.push(resLoanProduct.charges[index]);
                    }
                    return false;
                  }
                  return true;
                });
              });
            }
            resLoanProduct.charges = chargesOverride;

            const resCreateLoan = await createLoan(lmsToken, sheetData, {
              ...resLoanProduct,
              clientNumber: resCreateClient.data.outputVariables.clientNumber,
              productId: product.loanProductId
            });
            // console.log(`${TAG}.createLoan.result: `, resCreateLoan);
            await processLMSResponse(tableRecord.id, "loanCreationResponse", resCreateLoan, true, {
              isLoanCreated: true
            });

            if (resCreateLoan.status == 200) {
              const resupdateLoanCreationFeederSheet = await updateLoanCreationFeederSheet(tableRecord.id);
              console.log(`${TAG}.updateLoanCreation.result: `, resupdateLoanCreationFeederSheet);
              const resApproveLoan = await approveLoan(lmsToken, sheetData, {
                clientNumber: resCreateClient.data.outputVariables.clientNumber,
                loanNumber: resCreateLoan.data.outputVariables.loanNumber
              });
              // console.log(`${TAG}.approveLoan.result: `, resApproveLoan);
              await processLMSResponse(tableRecord.id, "loanApproveResponse", resApproveLoan, true);

              if (resApproveLoan.status == 200) {
                const resCreateDisbursement = await createDisbursement(lmsToken, sheetData, {
                  clientNumber: resCreateClient.data.outputVariables.clientNumber,
                  loanNumber: resCreateLoan.data.outputVariables.loanNumber
                });
                // console.log(`${TAG}.createDisbursement.result: `, resCreateDisbursement);
                await processLMSResponse(tableRecord.id, "loanDisbursementResponse", resCreateDisbursement, true, {
                  isProcessSuccess: true
                });

                if (resCreateDisbursement.status != 200) {
                  return await processFailure(
                    resCreateDisbursement,
                    tableRecord.id,
                    "repaymentResponse",
                    "create disbursement api"
                  );
                }
                return resCreateDisbursement;
              }
              return await processFailure(resApproveLoan, tableRecord.id, "loanApproveResponse", "approve loan api");
            }
            return await processFailure(resCreateLoan, tableRecord.id, "loanCreationResponse", "create loan api");
          }
          return await processFailure(
            resLoanProduct,
            tableRecord.id,
            "loanCreationResponse",
            "loan product details api"
          );
        }
        return await processFailure(resLosLogin, tableRecord.id, "loanCreationResponse", "los login api");
      }
      return await processFailure(resCreateClient, tableRecord.id, "userCreationResponse", "create client api");
    }
    return await processFailure(resBreValidation, tableRecord.id, "kulizaBREResponse", "bre validation api");
  } catch (error) {
    const errMsg = error
      ? error.response
        ? error.response.data
          ? error.response.data
          : error.response
        : error
      : "Something went wrong!";
    console.log(`${TAG}.processUpload.error: `, errMsg);
    return errMsg;
  } finally {
    return {
      status: 200
    };
  }
}

async function loginToBre() {
  console.log(`${TAG}.loginToBre: `);
  const result = await axiosLoginCall(kulizaConfig.BRE_LOGIN_URL, kulizaConfig.BRE_LOGIN_CREDS);
  return result;
}

async function validateFromBRE(token, data, product) {
  console.log(`${TAG}.validateFromBRE: `);
  // delete data.id; // delete table row id
  // console.log("feeder.sheet.data: ", data);
  // return { status: 200, data: [{ status: 200, data: { output: { FtCash_UBL: "Go" } } }] };
  const requestData = {};

  Object.keys(data).forEach((key) => {
    if (key !== "id") {
      const mapperMember = mapper[key];
      // check if there is a bre validation corresspondent for the key in data
      if (mapperMember && mapperMember.breKey) {
        requestData[`${mapperMember.breKey}-${mapperMember.breType}`] =
          data[key] && data[key] == "" ? null : data[key] || null;
      }
    }
  });

  // some static bre validation request processing
  const resBlackListingBreKey = `${mapper.residentialPinCodeBlackListed.breKey}-${mapper.residentialPinCodeBlackListed.breType}`;
  requestData[resBlackListingBreKey] = 0;
  const resPincodeMember = mapper.residentialPinCode.modelKey;
  if (data[resPincodeMember] && product.blackListedResidentialPincodes.includes(data[resPincodeMember])) {
    requestData[resBlackListingBreKey] = 1;
  }

  const busBlackListingBreKey = `${mapper.businessPinCodeBlackListed.breKey}-${mapper.businessPinCodeBlackListed.breType}`;
  requestData[busBlackListingBreKey] = 0;
  const busPincodeMember = mapper.businessPinCode.modelKey;
  if (data[busPincodeMember] && product.blackListedBusinessPincodes.includes(data[busPincodeMember])) {
    requestData[busBlackListingBreKey] = 1;
  }

  const today = new Date();

  const applDoB = new Date(data[mapper.dob.modelKey]);
  // console.log("applDoB: ", data[mapper.dob.modelKey]);
  requestData[`${mapper.age.breKey}-${mapper.age.breType}`] = today.getFullYear() - applDoB.getFullYear();

  const coApplDoB = new Date(data[mapper.coApplicantDob.modelKey]);
  // console.log("coApplDoB: ", coApplDoB);
  requestData[`${mapper.coApplicantAge.breKey}-${mapper.coApplicantAge.breType}`] =
    today.getFullYear() - coApplDoB.getFullYear();

  requestData[`${mapper.customerType.breKey}-${mapper.customerType.breType}`] =
    data[mapper.customerType.modelKey] || "New";

  // if (!requestData[mapper.tenureDays.breKey]) {
  //   requestData[mapper.tenureDays.breKey] = requestData[mapper.tenureMonths.breKey];
  // }

  return await axiosPostCall(kulizaConfig.BRE_VALIDATION_URL, token, {
    inputData: {
      ...requestData
    },
    productIds: [product.breId]
  });
}

async function loginToLos() {
  console.log(`${TAG}.loginToLos: `);
  const result = await axiosLoginCall(kulizaConfig.LOS_LOGIN_URL, null, kulizaConfig.LOS_PRODUCT_HEADER);
  return result;
}

async function getProductDetails(token, productId) {
  console.log(`${TAG}.getProductDetails: `);
  return await axiosGetCall(`${kulizaConfig.LOS_PRODUCT_URL}/${productId}`, token, {
    "Fineract-Platform-TenantId": "dev3-Oauth-Role-SR"
  });
}

async function getpartnerLoanId(productId) {
  console.log(`${TAG}.getpartnerLoanId: `);
  return await axiosGetCall(`${kulizaConfig.LOS_PRODUCT_URL}/${productId}`, token, {
    "Fineract-Platform-TenantId": "dev3-Oauth-Role-SR"
  });
}

async function createClient(token, data, addOnData = {}) {
  console.log(`${TAG}.createClient: `);
  // delete data.id; // delete table row id

  let requestData = {};

  Object.keys(data).forEach((key) => {
    if (key !== "id") {
      const mapperMember = mapper[key];
      // check if key is already defined in the database
      if (mapperMember && !mapperMember.isPreDefined) {
        if (mapperMember.modelKey === mapper.coApplicantDob.modelKey) {
          requestData[`actionableContext_${mapperMember.modelKey}`] = convertToKulizaFormat(data[key]);
        } else requestData[`actionableContext_${mapperMember.modelKey}`] = data[key];
      }
    }
  });

  const clientNameData = {};
  if (data[mapper.fullName.modelKey]) {
    // clientNameData[mapper.fullName.kulizaKey] = data[mapper.fullName.modelKey];
    clientNameData[mapper.firstName.kulizaKey] = data[mapper.firstName.modelKey];
    clientNameData[mapper.lastName.kulizaKey] = data[mapper.lastName.modelKey];
  } else {
    clientNameData[mapper.firstName.kulizaKey] = data[mapper.firstName.modelKey];
    clientNameData[mapper.lastName.kulizaKey] = data[mapper.lastName.modelKey];
  }

  requestData = {
    ...requestData,
    // mandatory fields
    ...clientNameData,
    actionableContext_dateOfBirth: convertToKulizaFormat(data[mapper.dob.modelKey]),
    actionableContext_submittedOnDate: convertToKulizaFormat(data[mapper.applicationDate.modelKey]),
    actionableContext_activationDate: convertToKulizaFormat(data[mapper.applicationDate.modelKey]),
    // optional fields
    actionableContext_gender: data[mapper.gender.modelKey] || null,
    actionableContext_pan: data[mapper.personalPanNumber.modelKey] || null,
    actionableContext_aadhar: data[mapper.aadharNumber.modelKey] || null,
    actionableContext_mobileNumber: data[mapper.mobileNumber.modelKey] || null,
    actionableContext_alternateMobileNumber: data[mapper.alternateMobileNumber.modelKey] || null,
    actionableContext_email: data[mapper.emailId.modelKey] || null,
    actionableContext_currAddressLine1: data[mapper.residentialAddress.modelKey] || null,
    actionableContext_currCity: data[mapper.residentialCity.modelKey] || null,
    actionableContext_currPincode: data[mapper.residentialPinCode.modelKey] || null,
    actionableContext_currState: data[mapper.residentialState.modelKey] || null,
    actionableContext_permSameCurr: data[mapper.permSameCurr.modelKey] || null,
    actionableContext_permAddressLine1: data[mapper.permanentAddress.modelKey] || null,
    actionableContext_permAddressLine2: data[mapper.permAddressLine2.modelKey] || null,
    actionableContext_permCountry: data[mapper.permCountry.modelKey] || null,

    // targetContext keys
    targetContext_processDefinitionKey: "adminMaker__createClient03",
    targetContext_officeId: "kolkata"
  };

  return await axiosPostCall(`${kulizaConfig.LMS_LENDING_URL}/client/create-service-request`, token, requestData);
}

async function createLoan(token, data, addOnData = {}) {
  console.log(`${TAG}.createLoan: `);
  const requestData = {
    // mandatory fields
    actionableContext_submittedOnDate: convertToKulizaFormat(data[mapper.submittedOnDate.modelKey] || new Date()),
    actionableContext_expectedDisbursementDate: convertToKulizaFormat(
      data[mapper.expectedDisbursementDate.modelKey] || new Date()
    ),
    actionableContext_principal: data[mapper.loanAmount.modelKey],
    // was added by Biswajit(Kuliza) on June 7, 2022 to tackle charges impl
    actionableContext_arthmateDisburementAmount: data[mapper.disbursementAmount.modelKey],

    actionableContext_numberOfRepayments: data[mapper.tenureDays.modelKey],
    actionableContext_interestRatePerPeriod:
      data[mapper.interestRate.modelKey] || data[mapper.interestRateMonthly.modelKey],
    actionableContext_allowPartialPeriodInterestCalcualtion: addOnData.allowPartialPeriodInterestCalcualtion,
    actionableContext_repaymentEvery: addOnData.repaymentEvery,
    actionableContext_repaymentFrequencyType: addOnData.repaymentFrequencyType.id,
    actionableContext_loanTermFrequency: addOnData.loanTermFrequency
      ? addOnData.loanTermFrequency
      : data[mapper.tenureDays.modelKey],
    actionableContext_loanTermFrequencyType: addOnData.loanTermFrequency
      ? addOnData.loanTermFrequencyType.id
      : addOnData.repaymentFrequencyType.id,
    actionableContext_amortizationType: addOnData.amortizationType.id,
    actionableContext_interestCalculationPeriodType: `${addOnData.interestCalculationPeriodType.id}`,
    actionableContext_interestType: `${addOnData.interestType.id}`,
    actionableContext_transactionProcessingStrategyId: addOnData.transactionProcessingStrategyId,
    actionableContext_chargesTable: addOnData.charges ? JSON.stringify(addOnData.charges) : "[]",
    actionableContext_disbursementData: data[mapper.disbursementData.modelKey] || "[]",
    actionableContext_isEqualAmortization: addOnData.isEqualAmortization,

    actionableContext_requestRelatedTo: "Create Loan",
    actionableContext_raisedOn: convertToKulizaFormat(data[mapper.applicationDate.modelKey]),
    actionableContext_loanType: "individual",
    // optional fields
    actionableContext_repaymentsStartingFromDate: data[mapper.firstRepaymentDate.modelKey] || null,
    actionableContext_graceOnArrearsAgeing: data[mapper.graceOnArrearsAgeing.modelKey] || null,
    actionableContext_graceOnInterestCharged: data[mapper.graceOnInterestCharged.modelKey] || null,
    actionableContext_graceOnInterestPayment: data[mapper.graceOnInterestPayment.modelKey] || null,
    actionableContext_graceOnPrincipalPayment: data[mapper.graceOnPrincipalPayment.modelKey] || null,
    actionableContext_inArrearsTolerance: data[mapper.inArrearsTolerance.modelKey] || null,
    actionableContext_maxOutstandingLoanBalance: data[mapper.maxOutstandingLoanBalance.modelKey] || "",
    actionableContext_numberOfAmortizationRepayments: data[mapper.numberOfAmortizationRepayments.modelKey] || "",
    actionableContext_stepIntervals: data[mapper.stepIntervals.modelKey] || "",
    // targetContext keys
    targetContext_processDefinitionKey: "adminMaker__createLoan02",
    targetContext_productId: `${addOnData.productId}`,
    targetContext_clientNumber: addOnData.clientNumber
  };

  return await axiosPostCall(`${kulizaConfig.LMS_LENDING_URL}/client/create-service-request`, token, requestData);
}

async function approveLoan(token, data, addOnData = {}) {
  console.log(`${TAG}.approveLoan: `);
  const requestData = {
    // mandatory fields
    actionableContext_approvedOnDate: convertToKulizaFormat(data[mapper.approvedOnDate.modelKey] || new Date()),
    actionableContext_approvedLoanAmount: data[mapper.approvedAmount.modelKey] || data[mapper.loanAmount.modelKey],
    actionableContext_expectedDisbursementDate: convertToKulizaFormat(
      data[mapper.expectedDisbursementDate.modelKey] || new Date()
    ),
    actionableContext_disbursementData: data[mapper.disbursementData.modelKey] || "[]",
    actionableContext_isTransactional: false,
    // targetContext keys
    targetContext_processDefinitionKey: "adminMaker__approveLoan01",
    targetContext_clientNumber: addOnData.clientNumber,
    targetContext_loanNumber: addOnData.loanNumber
  };

  return await axiosPostCall(`${kulizaConfig.LMS_LENDING_URL}/loan/create-service-request`, token, requestData);
}

async function createDisbursement(token, data, addOnData = {}) {
  console.log(`${TAG}.creaeDisbursement: `);
  const requestData = {
    // mandatory fields
    actionableContext_actualDisbursementDate: convertToKulizaFormat(
      data[mapper.actualDisbursementDate.modelKey] || new Date()
    ),
    actionableContext_transactionAmount: data[mapper.disbursementAmount.modelKey],
    actionableContext_isTransactional: false,
    actionableContext_paymentTypeId: data[mapper.paymentTypeId.modelKey] || "bankTransfer01",
    actionableContext_paymentTypeId2: data[mapper.paymentTypeId2.modelKey] || null,
    // targetContext keys
    targetContext_processDefinitionKey: "adminMaker__disburseLoan01",
    targetContext_requestType: "disburse",
    targetContext_clientNumber: addOnData.clientNumber,
    targetContext_loanNumber: addOnData.loanNumber
  };

  return await axiosPostCall(`${kulizaConfig.LMS_LENDING_URL}/loan/create-service-request`, token, requestData);
}

async function makeRepayment(token, data, addOnData = {}) {
  console.log(`${TAG}.makeRepayment: `);
  const requestData = {
    // mandatory fields
    actionableContext_transactionDate: data[mapper.applicationDate.modelKey],
    actionableContext_paymentTypeId: data[mapper.paymentTypeId.modelKey] || "bankTransfer01",
    actionableContext_paymentTypeId2: data[mapper.paymentTypeId2.modelKey] || null,
    actionableContext_transactionAmount: data[mapper.disbursementAmount.modelKey],
    actionableContext_applyCharge: data[mapper.applyCharge.modelKey],
    actionableContext_requestRelatedTo: "Make Repayment",
    actionableContext_repaymentMode: data[mapper.repaymentMode.modelKey],
    actionableContext_isTransactional: true,
    actionableContext_raisedOn: data[mapper.applicationDate.modelKey],
    actionableContext_instrumentType: data[mapper.instrumentType.modelKey],
    // targetContext keys
    targetContext_processDefinitionKey: "adminMaker__makeRepayment01",
    targetContext_requestType: "repayment",
    targetContext_clientNumber: addOnData.clientNumber,
    targetContext_loanNumber: addOnData.loanNumber
  };

  return await axiosPostCall(`${kulizaConfig.LMS_LENDING_URL}/loan/create-service-request`, token, requestData);
}

async function axiosLoginCall(url, body, headers = {}) {
  console.log(`${TAG}.axiosLoginCall: `, `url - ${url}, body - ${typeof body}, headers - ${headers}`);

  const result = await axios({
    method: "POST",
    url,
    data: body,
    headers: {
      ...headers
    }
  });

  return result.data;
}

async function axiosPostCall(url, token, body, headers = {}) {
  // console.log(
  //   `${TAG}.axiosPostCall: `,
  //   `url - ${url}, token - ${token}, body - ${JSON.stringify(body)}, headers - ${headers}`
  // );
  console.log(`${TAG}.axiosPostCall: `, `url - ${url}\nbody - ${JSON.stringify(body)}`);

  const result = await axios({
    method: "POST",
    url,
    data: body,
    headers: {
      ...headers,
      authorization: `Bearer ${token}`
    }
  });
  return result.data;
}

async function axiosGetCall(url, token, headers = {}) {
  // console.log(`${TAG}.axiosGetCall: `, `url - ${url}, token - ${token}, headers - ${headers}`);

  const result = await axios({
    method: "GET",
    url,
    headers: {
      ...headers,
      authorization: `Bearer ${token}`
    }
  });
  return result.data;
}

module.exports = {
  findProduct,
  loginToBre,
  getUploadResult,
  generateUploadResultSheet,
  getAllUploads,
  processUpload,
  addToProcessor,
  updateValidationFeederSheet,
  findLoanIdCount,
  markAsDuplicateRecord
};
