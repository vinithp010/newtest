const { v4: uuidv4 } = require("uuid");
const responses = require("../../../helpers/api-response/response.function");
const service = require("./kuliza.service");
const { convertExcelToJson } = require("../../../helpers/sheet.helper");
const documentSchemas = require("./kuliza.validation");
const { KULIZA_BRE_CONFIG } = require("./kuliza.config");
const json2xls = require("json2xls");
const fs = require("fs");

const TAG = "kuliza.controller";

const uploadFromMasterSheet = async (req, res) => {
  const rows = convertExcelToJson(req.file.path);

  if (rows !== null || rows !== undefined) {
    const fileUniqueId = uuidv4();

    Promise.all(
      (finalResult = rows.map(async (rowData) => {
        const validationResult = documentSchemas.sheetValidationSchema.validate(rowData);
        // console.log(`${TAG}.uploadFromMasterSheet: `, validationResult);
        if (validationResult.error) {
          return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);
        }

        return await service.processKulizaRequest(
          req.body.access_token,
          rowData,
          req.body.hitSuccessBre ? KULIZA_BRE_CONFIG.DEMO.SUCCESS_BRE : KULIZA_BRE_CONFIG.DEMO.FAILURE_BRE,
          fileUniqueId
        );
      }))
    )
      .then((result) =>
        // console.log(`${TAG}.uploadFromMasterSheet.result: `, result);
        responses.successResponse(res, fileUniqueId, rows, "Master sheet is being processed!")
      )
      .catch((error) => {
        console.log(`${TAG}.uploadFromMasterSheet.error: `, error);
        return responses.badRequestResponse(res, null, error.message);
      });
  }
};

const getSheetUploadStatus = async (req, res) => {
  service.getSheetUploadStatus(req.params.fileUniqueId, (error, result) => {
    if (error) {
      console.log(`${TAG}.getSheetUploadStatus.error: `, error);
      return responses.badRequestResponse(res, null, error);
    }

    // console.log(`${TAG}.getSheetUploadStatus.result: `, result);
    return responses.successResponse(res, null, result, "Master sheet status fetched!");
  });
};

const downloadSheetUploadStatus = async (req, res) => {
  service.downloadSheetUploadStatus(req.params.fileUniqueId, (error, result) => {
    if (error) {
      // console.log(`${TAG}.downloadSheetUploadStatus.error: `, error);
      return responses.badRequestResponse(res, null, error);
    }
    const xls = json2xls(result);
    const filename = "uploaded_file" + "_" + new Date().getTime() + ".xlsx";
    const filePath = __dirname + "/../../../../uploads/" + filename;

    fs.writeFileSync(filePath, xls, "binary");

    return res.download(filePath, xls);
  });
};

const getUploadSheetList = async (req, res) => {
  service.getUploadSheetList((error, result) => {
    if (error) {
      // console.log(`${TAG}.getUploadSheetList.error: `, error);
      return responses.badRequestResponse(res, null, error);
    }
    return responses.successResponse(res, null, result, "Upload file list fetched!");
  });
};

const getUploadList = async (req, res) => {
  const { page, pageSize } = req.query;
  service.getUploadList(pageSize, page, (error, result) => {
    if (error) {
      // console.log(`${TAG}.getUploadList.error: `, error);
      return responses.badRequestResponse(res, null, error);
    }
    return responses.successResponse(res, null, result, "Upload file list fetched!");
  });
};

const getUploadDetails = async (req, res) => {
  const { id } = req.params;
  if (!id) {
    return responses.badRequestResponse(res, null, null, "Please provide record Id");
  }
  service.getUploadDetails(id, (error, result) => {
    if (error) {
      // console.log(`${TAG}.getUploadDetails.error: `, error);
      return responses.badRequestResponse(res, id, error);
    }
    return responses.successResponse(res, id, result, "Upload file details fetched!");
  });
};

const addPartner = async (req, res) => {
  // const validationResult = documentSchemas.partner.validate(req.body);
  // console.log("addPartner: ", validationResult);
  // if (validationResult.error) {
  //   return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);
  // }

  service.addPartner(
    {
      ...req.body,
      partnerOnboarding_date: req.body.partnerOnboardingDate
    },
    (error, result) => {
      if (error) {
        console.log("addPartner.error: ", error);
        return responses.badRequestResponse(res, null, error.message);
      }

      console.log("addPartner.result: ", result);
      return responses.successResponse(res, null, result, "partner has been created successfully!");
    }
  );
};

const getPartners = async (req, res) => {
  service.getPartners((error, result) => {
    if (error) {
      console.log("getPartners.error: ", error);
      return responses.badRequestResponse(res, null, error.message);
    }

    console.log("getPartners.result: ", result);
    return responses.successResponse(res, null, result, "Partners has been successfully fetched!");
  });
};

const addProduct = async (req, res) => {
  const validationResult = documentSchemas.product.validate(req.body);
  console.log("addProduct: ", validationResult);
  if (validationResult.error) {
    return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);
  }
  const { config } = req.body;
  if (config && Object.keys(config)) {
    var uniqueValues = {};
    for (const key in config) {
      if (!uniqueValues?.hasOwnProperty(key)) {
        uniqueValues[key] = config[key];
      }
    };
    if (Object.keys(config).length !== Object.keys(uniqueValues).length) {
      return responses.badRequestResponse(res, null, "please remove duplicate keys fron configuration!", null);
    }
  }

  service.addProduct(req.body, (error, result) => {
    if (error) {
      console.log("addProduct.error: ", error);
      return responses.badRequestResponse(res, null, error.message);
    }

    console.log("addProduct.result: ", result);
    return responses.successResponse(res, null, result, "Product has been created successfully!");
  });
};

const updateProduct = async (req, res) => {
  const validationResult = documentSchemas.product.validate(req.body, {allowUnknown: true});
  console.log("updateProduct: ", validationResult);
  if (validationResult.error) {
    return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);
  }
  const { config } = req.body;
  if (config && Object.keys(config)) {
    var uniqueValues = {};
    for (const key in config) {
      if (!uniqueValues?.hasOwnProperty(key)) {
        uniqueValues[key] = config[key];
      }
    };
    if (Object.keys(config).length !== Object.keys(uniqueValues).length) {
      return responses.badRequestResponse(res, null, "please remove duplicate keys fron configuration!", null);
    }
  }

  service.updateProduct(req.body, (error, result) => {
    if (error) {
      console.log("updateProduct.error: ", error);
      return responses.badRequestResponse(res, null, error.message);
    }

    console.log("updateProduct.result: ", result);
    return responses.successResponse(res, null, result, "Product has been updated successfully!");
  });
};

const getProducts = async (req, res) => {
  service.getProducts((error, result) => {
    if (error) {
      console.log("getProducts.error: ", error);
      return responses.badRequestResponse(res, null, error.message);
    }

    console.log("getProducts.result: ", result);
    return responses.successResponse(res, null, result, "Products has been successfully fetched!");
  });
};

const getDetailedProducts = async (req, res) => {
  service.getDetailedProducts((error, result) => {
    if (error) {
      console.log("getDetailedProducts.error: ", error);
      return responses.badRequestResponse(res, null, error.message);
    }

    console.log("getDetailedProducts.result: ", result);
    return responses.successResponse(res, null, result, "Products has been successfully fetched!");
  });
};

const getDetailedPartners = async (req, res) => {
  service.getDetailedPartners((error, result) => {
    if (error) {
      console.log("getDetailedPartners.error: ", error);
      return responses.badRequestResponse(res, null, error.message);
    }

    console.log("getDetailedPartners.result: ", result);
    return responses.successResponse(res, null, result, "Partners has been successfully fetched!");
  });
};

module.exports = {
  uploadFromMasterSheet,
  getSheetUploadStatus,
  downloadSheetUploadStatus,
  getUploadSheetList,
  getUploadList,
  getUploadDetails,

  addPartner,
  getPartners,
  addProduct,
  updateProduct,
  getProducts,
  getDetailedProducts,
  getDetailedPartners
};
