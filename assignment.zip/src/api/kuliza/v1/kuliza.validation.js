const JoiBase = require("joi");
const JoiDate = require("@hapi/joi-date");

const Joi = JoiBase.extend(JoiDate);

const allowedValidationSchema = Joi.object().keys({
  applicationDate: Joi.date().format(JSON.parse(process.env.ACCEPTED_DATE_FORMATS)).required(),
  dob: Joi.date().format(JSON.parse(process.env.ACCEPTED_DATE_FORMATS)).required(),
  coApplicantDob: Joi.date().format(JSON.parse(process.env.ACCEPTED_DATE_FORMATS)).optional()
});

const mandatoryValidationSchema = Joi.object().keys({
  // sheet definitive keys
  partnerLoanId: Joi.string()
    .regex(/^([a-zA-Z0-9]+)$/)
    .required(), // Partner Loan ID
  applicationDate: Joi.date().format(JSON.parse(process.env.ACCEPTED_DATE_FORMATS)).raw().required(), // application_date
  fullName: Joi.string()
    .regex(/^([ a-zA-Z0-9 ]+)$/)
    .required(), // Full_Name
  fatherName: Joi.string()
    .regex(/^([a-zA-Z ]+)$/)
    .required(),
  residentialPinCode: Joi.number().min(100000).max(999999).required(),
  residentialCity: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .optional()
    .allow(""),
  residentialState: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .required(),
  businessState: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .optional()
    .allow(""),
  businessCity: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .optional()
    .allow(""),
  personalPanNumber: Joi.string()
    .regex(/^([A-Z]{3}[PHFATBLJG]{1}[A-Z]{1}[0-9]{4}[A-Z]{1})$/)
    .required(),
  poaNumber: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .required(),
  mobileNumber: Joi.number().integer().min(1000000000).max(9999999999).required(),
  dob: Joi.date().format(JSON.parse(process.env.ACCEPTED_DATE_FORMATS)).raw().required(),
  emailId: Joi.string()
    .email({
      tlds: {
        allow: false
      }
    })
    .required(),
  gender: Joi.string().valid("Male", "Female", "Others").required(),
  coBorrowerName: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .required(),
  coApplicantPan: Joi.string()
    .regex(/^([A-Z]{3}[PHFATBLJG]{1}[A-Z]{1}[0-9]{4}[A-Z]{1})$/)
    .required(),
  coApplicantDob: Joi.date().format(JSON.parse(process.env.ACCEPTED_DATE_FORMATS)).raw().required(),
  coApplicantAadhar: Joi.number().integer().min(1000).max(999999999999).required(),
  aadharNumber: Joi.number().integer().min(1000).max(999999999999).optional(),
  purpose: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .required(),
  customerType: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .required(),
  retailerName: Joi.string()
    .regex(/^([a-zA-Z ]+)$/)
    .required(),
  businessVintageOverall: Joi.number().integer().required(),
  businessType: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .required(),
  gstNumber: Joi.string()
    .regex(/^([a-zA-Z0-9]+)$/)
    .optional()
    .allow(""),
  shopStatus: Joi.string().required(),
  businessAddress: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .required(),
  businessPinCode: Joi.number().min(100000).max(999999).required(),
  bureauScore: Joi.number().integer().required(),
  coApplicantScore: Joi.number().integer().required(),
  residentialAddress: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .required(),
  permanentAddress: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .required(),
  residentialstatus: Joi.string().valid("Owned", "Rented", "Parenta").required(),
  bankName: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .required(),
  bankAccountHolderName: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .required(),
  bankAccountType: Joi.string()
    .regex(/^([a-zA-Z]+)$/)
    .required(),
  bankAccountNumber: Joi.number().integer().min(1).max(9999999999999999).required(),
  ifscCode: Joi.string()
    .regex(/^([A-Z]{4}0[0-9]{6})$/)
    .required(),
  partnerScore: Joi.number().min(0).max(1000).optional().allow(""),
  programType: Joi.string()
    .regex(/^([a-zA-Z0-9 ]+)$/)
    .required(),
  medianOfBankingTransaction: Joi.number().required(),
  averageOfBankingTransaction: Joi.number().required(),
  coApplicantPanImage: Joi.string().uri().required(),
  loanAmount: Joi.number().required(),
  tenureDays: Joi.number().integer().required(),
  installmentsOrTenor: Joi.number().integer().optional().allow(""),
  interestRate: Joi.number().required(),
  processingFee: Joi.number().integer().required(),
  gstOnProcessingFee: Joi.number().required(),
  additionalCharges: Joi.number().optional().allow(""),
  insuranceAmount: Joi.number().optional().allow(""),
  disbursementAmount: Joi.number().required(),
  panImage: Joi.string().uri().required(),
  poaFront: Joi.string().uri().required(),
  poaBack: Joi.string().uri().optional().allow(""),
  selfieImage: Joi.string().uri().optional().allow(""),
  coApplicantPoaFront: Joi.string().uri().required(),
  coApplicantPoaBack: Joi.string().uri().optional().allow(""),
  coApplicantSelfie: Joi.string().uri().optional().allow(""),
  retailerShopPhotoInside: Joi.string().uri().required(),
  retailerShopPhotoOutside: Joi.string().uri().required(),
  agreementPdf: Joi.string().uri().required(),
  sanctionLetterPdf: Joi.string().uri().required(),
  businessVintageProof: Joi.string().uri().required(),
  moa: Joi.string().optional().allow(""),
  aoa: Joi.string().optional().allow(""),
  kycDirector: Joi.string().uri().required(),
  businessProofS3Path: Joi.string().uri().required(),
  soaFile: Joi.string().uri().required(),
  poiValidation: Joi
    // .string()
    // .regex(/^([a-zA-Z0-9]+)$/)
    .optional()
    .allow(""),
  poaValidation: Joi
    // .string()
    // .regex(/^([a-zA-Z0-9]+)$/)
    .optional()
    .allow(""),
  repaymentJson: Joi.string().required()
});

const completeValidationSchema = Joi.object().keys({
  // sheet definitive keys
  partnerLoanId: Joi.string().required(), // Partner Loan ID
  applicationDate: Joi.date().format(process.env.ACCEPTED_DATE_FORMATS).required(), // application_date
  fullName: Joi.string().required(), // Full_Name
  fatherName: Joi.string().required(),
  residentialPinCode: Joi.number().max(999999).required(),
  personalPanNumber: Joi.string().required(),
  poaNumber: Joi.number().required(),
  mobileNumber: Joi.number().min(0000000000).required(),
  dob: Joi.date().format(process.env.ACCEPTED_DATE_FORMATS).required(),
  emailId: Joi.string().required(),
  gender: Joi.string().required(),
  coBorrowerName: Joi.string().required(),
  coApplicantPan: Joi.string().optional(),
  coApplicantDob: Joi.date().format(process.env.ACCEPTED_DATE_FORMATS).required(),
  coApplicantAadhar: Joi.number().required(),
  purpose: Joi.string().required(),
  customerType: Joi.string().required().valid("Repeat", "New"),
  retailerName: Joi.string().required(),
  businessVintageOverall: Joi.number().required(),
  businessType: Joi.string().required(),
  gstNumber: Joi.string().optional(),
  shopStatus: Joi.string().required(),
  businessAddress: Joi.string().required(),
  businessPinCode: Joi.number().max(999999).required(),
  bureauScore: Joi.number().required(),
  coApplicantScore: Joi.number().required(),
  residentialAddress: Joi.string().required(),
  permanentAddress: Joi.string().required(),
  residentialstatus: Joi.string().required(),
  bankName: Joi.string().required(),
  bankAccountHolderName: Joi.string().required(),
  bankAccountType: Joi.string().required(),
  bankAccountNumber: Joi.string().required(),
  ifscCode: Joi.string().required(),
  programType: Joi.string().required(),
  medianOfBankingTransaction: Joi.number().required(),
  averageOfBankingTransaction: Joi.number().required(),
  loanAmount: Joi.number().required(),
  // tenureMonths: Joi.number().required(),
  tenureDays: Joi.number().required(),
  installmentsOrTenor: Joi.number().optional(),
  interestRate: Joi.number().required(),
  processingFee: Joi.number().required(),
  gstOnProcessingFee: Joi.number().required(),
  additionalCharges: Joi.number().optional(),
  insuranceAmount: Joi.number().optional(),
  disbursementAmount: Joi.number().required(),
  panImage: Joi.string().required(),
  poaFront: Joi.string().required(),
  poaBack: Joi.string().optional(),
  selfieImage: Joi.string().optional(),
  coApplicantPanImage: Joi.string().required(),
  coApplicantPoaFront: Joi.string().required(),
  coApplicantPoaBack: Joi.string().optional(),
  coApplicantSelfie: Joi.string().optional(),
  retailerShopPhotoInside: Joi.string().required(),
  retailerShopPhotoOutside: Joi.string().required(),
  agreementPdf: Joi.string().required(),
  sanctionLetterPdf: Joi.string().required(),
  businessVintageProof: Joi.string().required(),
  moa: Joi.string().optional(),
  aoa: Joi.string().optional(),
  kycDirector: Joi.string().required(),
  businessProofS3Path: Joi.string().required(),
  soaFile: Joi.string().required(),
  poiValidation: Joi.string().optional(),
  poaValidation: Joi.string().optional(),
  repaymentJson: Joi.string().required(),

  // addtional keys added in qa phase
  middlName: Joi.string().optional(),
  poaType: Joi.string().optional(),
  industrySegment: Joi.string().optional(),
  montlySales: Joi.number().optional(),
  monthlyNumberOfTransactions: Joi.number().optional(),
  shopActivityStatus: Joi.number().optional(),
  typeOfDisbursement: Joi.string().optional(),
  maritalStatus: Joi.string().optional(),
  aadharNumber: Joi.number().optional(),
  annualIncome: Joi.number().optional(),
  dailyIncome: Joi.number().optional(),
  partnerScore: Joi.number().optional(),
  installmentsOrTenor: Joi.number().optional(),
  processingFeeIncludingGst: Joi.number().optional(),
  upfrontInterestForFirstMonth: Joi.number().optional(),
  brokenPeriodInterest: Joi.number().optional(),
  poa: Joi.string().optional(),
  panValidationResponseJson: Joi.string().optional(),
  aadhaarCardDoc: Joi.string().optional(),
  agreementS3Path: Joi.string().optional(),
  residenceVerification: Joi.string().optional(),
  businessVerification: Joi.string().optional(),
  installmentType: Joi.string().optional(),
  firstRepaymentDate: Joi.string().optional(),

  // additional bre validation keys
  coApplicantAge: Joi.number().optional(),
  applicantAge: Joi.number().optional(),
  coApplicantCount: Joi.number().optional(),

  // create client mandatory keys
  firstName: Joi.string().optional(),
  lastName: Joi.string().optional(),
  submittedOnDate: Joi.date().format(process.env.ACCEPTED_DATE_FORMATS).optional(),

  // create loan mandatory keys
  submittedOnDate: Joi.date().format(process.env.ACCEPTED_DATE_FORMATS).optional(),
  expectedDisbursementDate: Joi.date().format(process.env.ACCEPTED_DATE_FORMATS).optional(),
  interestRate: Joi.number().optional(), // interestRatePerPeriod: Joi.number().required(),
  interestRateMonthly: Joi.number().optional(), // interestRatePerPeriod: Joi.number().required(),
  disbursementData: Joi.string().optional(),

  // approve loan mandatory fields
  approvedOnDate: Joi.date().format(process.env.ACCEPTED_DATE_FORMATS).optional(),
  approvedAmount: Joi.number().optional(),

  // make disbursement mandatory fields
  actualDisbursementDate: Joi.date()
    .format(JSON.parse(JSON.stringify(process.env.ACCEPTED_DATE_FORMATS)))
    .raw()
    .optional()

  // make repayment mandatory fields (not in use as of May 25, 2022)
  // applyCharge: Joi.string().required(),
  // repaymentMode: Joi.number().required(),
  // instrumentType: Joi.string().required()
});
const product = Joi.object().keys({
  loanProductId: Joi.number().optional(),
  config: Joi.object().optional(),
  name: Joi.string().optional(),
  type: Joi.string().optional(),
  partnerId: Joi.number().optional(),
  breId: Joi.number().optional(),
  blackListedBusinessPincodes: Joi.array().optional(),
  blackListedResidentialPincodes: Joi.array().optional()
});

module.exports = {
  allowedValidationSchema,
  completeValidationSchema,
  mandatoryValidationSchema,
  product
};
