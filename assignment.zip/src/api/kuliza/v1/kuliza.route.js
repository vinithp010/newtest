const router = require("express").Router();
const controller = require("./kuliza.async-controller");
const syncController = require("./kuliza.controller");
const upload = require("../../../helpers/multer.helper");

router.post("/uploadMasterSheet", upload.single("masterSheet"), controller.uploadMasterSheet);
router.get("/sheets", controller.getSheets);
router.get("/sheetStatus/:fileUniqueid", controller.getSheetStatus);

router.get("/sheetUploadList", syncController.getUploadSheetList);
router.get("/sheetUploadStatusDownload/:fileUniqueId", syncController.downloadSheetUploadStatus);

router.get("/uploadDataList", syncController.getUploadList);
router.get("/uploadDetails/:id", syncController.getUploadDetails);

router.post("/partners", syncController.addPartner);
router.get("/partners", syncController.getPartners);
router.post("/products", syncController.addProduct);
router.put("/products", syncController.updateProduct);
router.get("/products", syncController.getProducts);
router.get("/detailedProducts", syncController.getDetailedProducts);
router.get("/detailedPartners", syncController.getDetailedPartners);

module.exports = router;
