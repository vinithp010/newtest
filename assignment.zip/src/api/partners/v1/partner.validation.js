const Joi = require("joi");

const createPartnerSchema = Joi.object().keys({
  partnerDbId: Joi.string().optional(),
  partnerName: Joi.string().required(),
  partnerType: Joi.string().optional(),
  partnerOnboardingDate: Joi.date().optional(),
  createdBy: Joi.number().optional(),
  updatedBy: Joi.number().optional()
});

const createProductSchema = Joi.object().keys({
  name: Joi.string().required(),
  type: Joi.string().optional(),
  partnerId: Joi.number().required(),
  breId: Joi.number().optional(),
  createdBy: Joi.number().optional(),
  updatedBy: Joi.number().optional()
});

module.exports = {
  createPartnerSchema,
  createProductSchema
};
