const db = require("../../../../database/models/index");

const TAG = "partner.service";

// const TPartnerProcessor = db.TPartnerProcessor;
const TPartner = db.TPartner;
// const TPartnerExtended = db.TPartnerExtended;
// const TProductProcessor = db.TProductProcessor;
const TProduct = db.TProduct;
// const TProductExtended = db.TProductExtended;

// function addToPartnerProcessor(data, callback) {
//   TPartnerProcessor.create({
//     uuid: null,
//     partnerData: JSON.stringify(data)
//   })
//     .then((result) => callback(null, result))
//     .catch((error) => callback(error, null));
// }

function addPartner(data, callback) {
  TPartner.create(data)
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getAllPartners(callback) {
  TPartner.findAll()
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getPartnerById(lineId, callback) {
  TPartner.findOne({ id: lineId })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function updatePartner(lineId, data, callback) {
  TPartner.update(data, { where: { id: lineId }, returning: true })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function removePartner(lineId, callback) {
  TPartner.delete({ where: { id: lineId } })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

// function addToProductProcessor(data, callback) {
//   TProductProcessor.create({
//     uuid: null,
//     productData: JSON.stringify(data)
//   })
//     .then((result) => callback(null, result))
//     .catch((error) => callback(error, null));
// }

function addProduct(data, callback) {
  TProduct.create(data)
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getAllProducts(callback) {
  TProduct.findAll()
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getProductById(lineId, callback) {
  TProduct.findOne({ id: lineId })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function updateProduct(lineId, data, callback) {
  TProduct.update(data, { where: { id: lineId }, returning: true })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function removeProduct(lineId, callback) {
  TProduct.delete({ where: { id: lineId } })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

module.exports = {
  addPartner,
  getAllPartners,
  getPartnerById,
  updatePartner,
  removePartner,

  addProduct,
  getAllProducts,
  getProductById,
  updateProduct,
  removeProduct
};
