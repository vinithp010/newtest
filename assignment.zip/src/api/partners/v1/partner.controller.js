const responses = require("../../../helpers/api-response/response.function");
const service = require("./partner.service");
const documentSchemas = require("./partner.validation");

const TAG = "partner.controller";

const addPartner = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.addPartner: `, req.body);

  service.addToProcessor(req.body, (error, result) => {
    if (error) {
      console.log(`${TAG}.addPartner.Processor.error: `, error);
    }

    console.log(`${TAG}.addPartner.Processor.result: `, result);

    const validationResult = documentSchemas.createPartnerSchema.validate(req.body);
    console.log(`${TAG}.addPartner: `, validationResult);
    if (validationResult.error)
      return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);

    service.addPartner(
      {
        uuid: req.body.uuid,
        monthlyIncome: req.body.monthly_income,
        partnerAmount: req.body.partner_amount
      },
      (error, result) => {
        if (error) {
          console.log(`${TAG}.addPartner.error: `, error);
          return responses.badRequestResponse(res, borrowerId, error["message"]);
        }

        console.log(`${TAG}.addPartner.result: `, result);
        return responses.successResponse(res, borrowerId, result, "Partner has been created successfully!");
      }
    );
  });
};

const getAllPartners = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.getAll: `);

  service.getAll((error, result) => {
    if (error) {
      console.log(`${TAG}.getAll.error: `, error);
      return responses.badRequestResponse(res, borrowerId, error["message"]);
    }

    console.log(`${TAG}.getAll.result: `, result);
    return responses.successResponse(res, borrowerId, result, "Partners has been successfully fetched!");
  });
};

const getPartnerById = async (req, res) => {
  const partnerId = req.params.partnerId;
  console.log(`${TAG}.getById: `);

  service.getById(partnerId, (error, result) => {
    if (error) {
      console.log(`${TAG}.getById.error: `, error);
      return responses.badRequestResponse(res, partnerId, error["message"]);
    }

    console.log(`${TAG}.getById.result: `, result);
    return responses.successResponse(res, partnerId, result, "Partner has been successfully fetched!");
  });
};

const searchForPartner = async (req, res) => {};

const updatePartner = async (req, res) => {
  const partnerId = req.params.partnerId;
  console.log(`${TAG}.updatePartner: `, req.body);

  service.addToProcessor(req.body, (error, result) => {
    if (error) {
      console.log(`${TAG}.updatePartner.Processor.error: `, error);
    }

    console.log(`${TAG}.updatePartner.Processor.result: `, result);

    const validationResult = documentSchemas.updatePartnerSchema.validate(req.body);
    console.log(`${TAG}.updatePartner: `, validationResult);
    if (validationResult.error)
      return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);

    service.updatePartner(
      partnerId,
      {
        uuid: req.body.uuid,
        amPartnerPartnerId: req.body.am_partner_id,
        monthlyIncome: req.body.monthly_income,
        updatedPartnerAmount: req.body.updated_partner_amount,
        updatedLoanAgreement: req.body.updated_loan_agreement,
        updatedSanctionLetter: req.updated_sanction_letter
      },
      (error, result) => {
        if (error) {
          console.log(`${TAG}.updatePartner.error: `, error);
          return responses.badRequestResponse(res, partnerId, error["message"], { borrowerId: partnerId });
        }

        console.log(`${TAG}.updatePartner.result: `, result);
        return responses.successResponse(res, partnerId, result, "Agreement docs updated successfully!");
      }
    );
  });
};

const removePartner = async (req, res) => {
  const partnerId = req.params.partnerId;
  console.log(`${TAG}.removePartner: `);

  service.removePartner(partnerId, (error, result) => {
    if (error) {
      console.log(`${TAG}.removePartner.error: `, error);
      return responses.badRequestResponse(res, null, error["message"], { partnerId });
    }

    console.log(`${TAG}.removePartner.result: `, result);
    return responses.successResponse(res, borrowerId, result, "Partner for the borrower has been successfully removed!");
  });
};

const addProduct = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.addProduct: `, req.body);

  service.addToProcessor(req.body, (error, result) => {
    if (error) {
      console.log(`${TAG}.addProduct.Processor.error: `, error);
    }

    console.log(`${TAG}.addProduct.Processor.result: `, result);

    const validationResult = documentSchemas.createProductSchema.validate(req.body);
    console.log(`${TAG}.addProduct: `, validationResult);
    if (validationResult.error)
      return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);

    service.addProduct(
      {
        uuid: req.body.uuid,
        monthlyIncome: req.body.monthly_income,
        partnerAmount: req.body.partner_amount
      },
      (error, result) => {
        if (error) {
          console.log(`${TAG}.addProduct.error: `, error);
          return responses.badRequestResponse(res, borrowerId, error["message"]);
        }

        console.log(`${TAG}.addProduct.result: `, result);
        return responses.successResponse(res, borrowerId, result, "Product has been created successfully!");
      }
    );
  });
};

const getAllProducts = async (req, res) => {
  const borrowerId = req.params.borrowerId;
  console.log(`${TAG}.getAll: `);

  service.getAll((error, result) => {
    if (error) {
      console.log(`${TAG}.getAll.error: `, error);
      return responses.badRequestResponse(res, borrowerId, error["message"]);
    }

    console.log(`${TAG}.getAll.result: `, result);
    return responses.successResponse(res, borrowerId, result, "Products has been successfully fetched!");
  });
};

const getProductById = async (req, res) => {
  const partnerId = req.params.partnerId;
  console.log(`${TAG}.getById: `);

  service.getById(partnerId, (error, result) => {
    if (error) {
      console.log(`${TAG}.getById.error: `, error);
      return responses.badRequestResponse(res, partnerId, error["message"]);
    }

    console.log(`${TAG}.getById.result: `, result);
    return responses.successResponse(res, partnerId, result, "Product has been successfully fetched!");
  });
};

const searchForProduct = async (req, res) => {};

const updateProduct = async (req, res) => {
  const partnerId = req.params.partnerId;
  console.log(`${TAG}.updateProduct: `, req.body);

  service.addToProcessor(req.body, (error, result) => {
    if (error) {
      console.log(`${TAG}.updateProduct.Processor.error: `, error);
    }

    console.log(`${TAG}.updateProduct.Processor.result: `, result);

    const validationResult = documentSchemas.updateProductSchema.validate(req.body);
    console.log(`${TAG}.updateProduct: `, validationResult);
    if (validationResult.error)
      return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);

    service.updateProduct(
      partnerId,
      {
        uuid: req.body.uuid,
        amProductId: req.body.am_partner_id,
        monthlyIncome: req.body.monthly_income,
        updatedProductAmount: req.body.updated_partner_amount,
        updatedLoanAgreement: req.body.updated_loan_agreement,
        updatedSanctionLetter: req.updated_sanction_letter
      },
      (error, result) => {
        if (error) {
          console.log(`${TAG}.updateProduct.error: `, error);
          return responses.badRequestResponse(res, partnerId, error["message"], { borrowerId: partnerId });
        }

        console.log(`${TAG}.updateProduct.result: `, result);
        return responses.successResponse(res, partnerId, result, "Agreement docs updated successfully!");
      }
    );
  });
};

const removeProduct = async (req, res) => {
  const partnerId = req.params.partnerId;
  console.log(`${TAG}.removeProduct: `);

  service.removeProduct(partnerId, (error, result) => {
    if (error) {
      console.log(`${TAG}.removeProduct.error: `, error);
      return responses.badRequestResponse(res, null, error["message"], { partnerId });
    }

    console.log(`${TAG}.removeProduct.result: `, result);
    return responses.successResponse(res, borrowerId, result, "Product for the borrower has been successfully removed!");
  });
};

module.exports = {
  addPartner,
  getAllPartners,
  getPartnerById,
  searchForPartner,
  updatePartner,
  removePartner,

  addProduct,
  getAllProducts,
  getProductById,
  searchForProduct,
  updateProduct,
  removeProduct
};
