const router = require("express").Router();
const controller = require("./partner.controller");

router.post("/", controller.addLine);
router.get("/", controller.getAll);
router.get("/:lineId", controller.getById);
router.get("/search", controller.searchForLine);
router.put("/:lineId", controller.updateLine);
router.delete("/:lineId", controller.removeLine);

router.post("/:partnerId", controller.addLine);
router.get("/:partnerId", controller.getAll);
router.get("/:partnerId/:productId", controller.getById);
router.get("/:partnerId/search", controller.searchForLine);
router.put("/:partnerId/:productId", controller.updateLine);
router.delete("/:partnerId/:productId", controller.removeLine);

module.exports = router;
