const router = require("express").Router();

router.use("/v1", require("./v1/bureau.route"));

module.exports = router;