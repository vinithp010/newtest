const router = require("express").Router();
const controller = require("./bureau.controller");

router.post("/", controller.addUser);
router.get("/", controller.getListUsers);
router.get("/:bureauId", controller.getById);
router.get("/search", controller.userSearch);
router.put("/", controller.updateUser);
router.delete("/:bureauId", controller.removeUser);

module.exports = router;
