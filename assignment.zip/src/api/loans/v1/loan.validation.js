const Joi = require("joi");

const loanRequestAPI = Joi.object().keys({
  uuid: Joi.number().required().min(1),
  aMLineID: Joi.string().min(10).max(30).required("aMLineID is required"),
  partnerLoanID: Joi.string().required("partnerLoanID is required"),
  loanAmount: Joi.number().min(1).max(100).required("loanAmount is required"),
  additionalcharges: Joi.number().min(1).max(100).required("additionalcharges is required"),
  interestrate: Joi.number().min(1).max(100).required("interestrate is required"),
  insuranceamount: Joi.number().min(1).max(100).required("insuranceamount is required"),
  disbursementamount: Joi.number().min(1).max(100).required("disbursementamount is required")
});

const loanProcessSchema = Joi.object().keys({
  uuid: Joi.string().min(10).max(30).required("uuid is required"),
  amLineId: Joi.string().min(10).max(30).required("aMLineID is required"),
  borrowerBankName: Joi.string().required("bankname is required"),
  borrowerAccountType: Joi.string().min(1).max(100).required("bankaccounttype is required"),
  borrowerBankAccount: Joi.string().min(1).max(100).required("bankaccountnumber is required"),
  repaymentJSON: Joi.object().min(1).max(100).required("repaymentJSON is required"),
  umrn: Joi.string().min(1).max(100).required("umrn is required"),
  tenureMonths: Joi.string().min(1).max(100).required("tenureMonths is required"),
  borrowerIFSC: Joi.string().min(1).max(100).required("borrowerIFSC is required")
});

const createLoanSchema = Joi.object().keys({
  uuid: Joi.number().required().min(1),
  partner_user_id: Joi.string().required().alphanum().max(1000),
  am_line_id: Joi.string().optional().alphanum().max(1000),
  loan_amount: Joi.number().required().min(1),
  processing_fee: Joi.number().required().min(1),
  gst: Joi.number().required().min(1),
  interest_rate: Joi.number().required().min(1),
  disbursement_amount: Joi.number().required().min(1)
});

const uploadLASchema = Joi.object().keys({
  uuid: Joi.number().required().min(1),
  documentId: Joi.number().required().min(1),
  sanction_letter: Joi.string().required().alphanum().max(1000),
  agreement: Joi.string().required().alphanum().max(1000),
  merged_letters: Joi.string().required().alphanum().max(1000)
});

const tRepaymentSchema = Joi.object().keys({
  loanId: Joi.number().min(1),
  uuid: Joi.string().min(1).required("uuid is required"),
  partnerId: Joi.number().min(1),
  amLoanId: Joi.string().min(1).required("amLoanId is required"),
  amLineId: Joi.number().min(1).required("amLineId is required"),
  repaymentDueAmount: Joi.number().min(1).required("repaymentDueAmount is required"),
  principalDueAmount: Joi.number().min(1).required("principalDueAmount is required"),
  interestDueAmount: Joi.number().min(1).required("interestDueAmount is required"),
  repaymentDueDate: Joi.date().required("repaymentDueDate is required"),
  repaymentTag: Joi.string().min(1).required("repaymentTag is required"),
  repaymentPaidAmount: Joi.number().min(1).required("repaymentPaidAmount is required"),
  principalPaidAmount: Joi.number().min(1).required("principalPaidAmount is required"),
  interestPaidAmount: Joi.number().min(1).required("interestPaidAmount is required"),
  additionalCharges: Joi.number().min(1).required("additionalCharges is required"),
  transactionNumber: Joi.string().min(1).required("transactionNumber is required"),
  transactionDate: Joi.date().required("transactionDate is required"),
  repaymentId: Joi.number().min(1),
  repaymentDate: Joi.date(),
  paymentMode: Joi.string().min(1),
  otherChargesAmount: Joi.number().min(1),
  repaymentAmount: Joi.number().min(1),
  principalAmount: Joi.number().min(1),
  interestAmount: Joi.number().min(1),
  UTRNumber: Joi.number().min(1)
});

module.exports = {
  loanRequestAPI,
  loanProcessSchema,
  createLoanSchema,
  uploadLASchema,
  tRepaymentSchema
};
