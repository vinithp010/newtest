const db = require("./../../../../database/models/index");

const TAG = "loan.service";

const TLoanProcessor = db.TLoanProcessor;
const TLoan = db.TLoan;
const TLoanExtended = db.TLoanExtended;

const TDocument = db.TDocument;

function addToProcessor(data, callback) {
  TLoanProcessor.create({
    uuid: null,
    loanData: JSON.stringify(data)
  })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function addForBorrower(data, callback) {
  TLoan.create(data)
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getAll(callback) {
  TLoan.findAll()
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function getForBorrower(borrowerId, callback) {
  TLoan.findOne({ uuid: borrowerId })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function updateLAForBorrower(borrowerId, data, callback) {
  TDocument.update(data, { where: { uuid: borrowerId } })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function updateForBorrower(borrowerId, data, callback) {
  TLoan.update(data, { where: { uuid: borrowerId } })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function removeLoan(loanId, callback) {
  TLoan.delete({ where: { id: loanId } })
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

function addtRepayment(data, callback) {
  TRepayment.create(data)
    .then((result) => callback(null, result))
    .catch((error) => callback(error, null));
}

module.exports = {
  addToProcessor,
  addForBorrower,
  getAll,
  getForBorrower,
  updateLAForBorrower,
  updateForBorrower,
  removeLoan,
  addtRepayment
};
