const responses = require("../../../helpers/api-response/response.function");
const service = require("./loan.service");
const documentSchemas = require("./loan.validation");

const TAG = "loan.controller";

const addLoan = async (req, res) => {
  const { borrowerId } = req.params;
  console.log(`${TAG}.addLoan: `, req.body);

  service.addToProcessor(req.body, (error, result) => {
    if (error) {
      console.log(`${TAG}.addLoan.Processor.error: `, error);
    }

    console.log(`${TAG}.addLoan.Processor.result: `, result);

    const validationResult = documentSchemas.createLoanSchema.validate(req.body);
    console.log(`${TAG}.addLoan: `, validationResult);
    if (validationResult.error) {
      return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);
    }

    service.addForBorrower(
      {
        partnerUserId: req.body.partner_user_id,
        amLineId: req.body.am_line_id,
        loanAmount: req.body.loan_amount,
        processingFee: req.body.processing_fee,
        gst: req.body.gst,
        interestRate: req.body.interest_rate,
        disbursementAmount: req.body.disbursement_amount,
        uuid: req.body.uuid,
        createdBy: req.body.created_by,
        updatedBy: req.body.updated_by
      },
      (error, result) => {
        if (error) {
          console.log(`${TAG}.addLoan.error: `, error);
          return responses.badRequestResponse(res, borrowerId, error.message);
        }

        console.log(`${TAG}.addLoan.result: `, result);
        return responses.successResponse(res, borrowerId, result, "Loan has been created successfully!");
      }
    );
  });
};

const getAll = async (req, res) => {
  const { borrowerId } = req.params;
  console.log(`${TAG}.getAll: `);

  service.getAll((error, result) => {
    if (error) {
      console.log(`${TAG}.getAll.error: `, error);
      return responses.badRequestResponse(res, borrowerId, error.message);
    }

    console.log(`${TAG}.getAll.result: `, result);
    return responses.successResponse(res, borrowerId, result, "Loans has been successfully fetched!");
  });
};

const getForBorrower = async (req, res) => {
  const { borrowerId } = req.params;
  console.log(`${TAG}.getForBorrower: `);

  service.getForBorrower(borrowerId, (error, result) => {
    if (error) {
      console.log(`${TAG}.getForBorrower.error: `, error);
      return responses.badRequestResponse(res, borrowerId, error.message);
    }

    console.log(`${TAG}.getForBorrower.result: `, result);
    return responses.successResponse(res, borrowerId, result, "Loan for the borrower has been successfully fetched!");
  });
};

const searchForBorrower = async (req, res) => {};

const updateLoan = async (req, res) => {};

const updateLAForBorrower = async (req, res) => {
  const { borrowerId } = req.params;
  console.log(`${TAG}.updateLAForBorrower: `, req.body);

  service.addToProcessor(req.body, (error, result) => {
    if (error) {
      console.log(`${TAG}.updateLAForBorrower.Processor.error: `, error);
    }

    console.log(`${TAG}.updateLAForBorrower.Processor.result: `, result);

    const validationResult = documentSchemas.uploadLASchema.validate(req.body);
    console.log(`${TAG}.updateLAForBorrower: `, validationResult);
    if (validationResult.error) {
      return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);
    }

    service.updateLAForBorrower(
      borrowerId,
      {
        sanctionLetter: req.body.sanction_letter,
        agreement: req.body.agreement,
        mergedLetters: req.body.merged_letters,
        updatedBy: req.body.updated_by
      },
      (error, result) => {
        if (error) {
          console.log(`${TAG}.updateLAForBorrower.error: `, error);
          return responses.badRequestResponse(res, borrowerId, error.message, {
            borrowerId
          });
        }

        console.log(`${TAG}.updateLAForBorrower.result: `, result);
        return responses.successResponse(res, borrowerId, result, "Agreement docs updated successfully!");
      }
    );
  });
};

const removeLoan = async (req, res) => {
  const { loanId } = req.params;
  console.log(`${TAG}.removeLoan: `);

  service.removeLoan(loanId, (error, result) => {
    if (error) {
      console.log(`${TAG}.removeLoan.error: `, error);
      return responses.badRequestResponse(res, null, error.message, {
        loanId
      });
    }

    console.log(`${TAG}.removeLoan.result: `, result);
    return responses.successResponse(res, borrowerId, result, "Loan for the borrower has been successfully removed!");
  });
};

const loanprocess = async (req, res) => {
  const { borrowerId } = req.params;
  console.log(`${TAG}.loanprocess: `, req.body);

  const validationResult = documentSchemas.loanProcessSchema.validate(req.body);
  console.log(`${TAG}.addLoan: `, validationResult);
  if (validationResult.error) {
    return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);
  }

  service.addForBorrower(
    {
      uuid: req.body.uuid,
      amLineId: req.body.amLineId,
      borrowerBankName: req.body.borrowerBankName,
      borrowerAccountType: req.body.borrowerAccountType,
      borrowerBankAccount: req.body.borrowerBankAccount,
      borrowerIFSC: req.body.borrowerIFSC,
      repaymentJSON: req.body.repaymentJSON,
      umrn: req.body.umrn,
      tenureMonths: req.body.tenureMonths
    },
    (error, result) => {
      if (error) {
        console.log(`${TAG}.loanprocess.error: `, error);
        return responses.badRequestResponse(res, borrowerId, error.message);
      }

      console.log(`${TAG}.addLoan.result: `, result);
      return responses.successResponse(res, borrowerId, result, "Loan process has been created successfully!");
    }
  );
};


const tRepayment = async (req, res) => {
  const {
 borrowerId
} = req.params;
  console.log(`${TAG}.tRepayment: `, req.body);

  const validationResult = documentSchemas.tRepaymentSchema.validate(req.body);
  console.log(`${TAG}.tRepayment: `, validationResult);
  if (validationResult.error) {
    return responses.badRequestResponse(res, null, "Validation failed!", validationResult.error);
  }

  service.addtRepayment(
    {
      uuid: req.body.uuid,
      amLoanId: req.body.amLoanId,
      amLineId: req.body.amLineId,
      repaymentDueAmount: req.body.repaymentDueAmount,
      principalDueAmount: req.body.principalDueAmount,
      interestDueAmount: req.body.interestDueAmount,
      repaymentDueDate: req.body.repaymentDueDate,
      repaymentTag: req.body.repaymentTag,
      repaymentPaidAmount: req.body.repaymentPaidAmount,
      principalPaidAmount: req.body.principalPaidAmount,
      interestPaidAmount: req.body.interestPaidAmount,
      additionalCharges: req.body.additionalCharges,
      transactionNumber: req.body.transactionNumber,
      transactionDate: req.body.transactionDate
    },
    (error, result) => {
      if (error) {
        console.log(`${TAG}.tRepayment.error: `, error);
        return responses.badRequestResponse(res, borrowerId, error.message);
      }

      console.log(`${TAG}.tRepayment.result: `, result);
      return responses.successResponse(res, borrowerId, result, "tRepayment has been created successfully!");
    }
  );
};

module.exports = {
  addLoan,
  getAll,
  getForBorrower,
  searchForBorrower,
  updateLoan,
  updateLAForBorrower,
  removeLoan,
  loanprocess,
  tRepayment
};
