"use strict";

const router = require("express").Router();
const controller = require("./loan.controller");

router.post("/forBorrower/:borrowerId", controller.addLoan);
router.get("/", controller.getAll);
router.get("/forBorrower/:borrowerId", controller.getForBorrower);
router.get("/search/forBorrower/:borrowerId", controller.searchForBorrower);
router.put("/forBorrower/:borrowerId", controller.updateLoan);
router.put("/updateLoanAgreement/forBorrower/:borrowerId", controller.updateLAForBorrower);
router.delete("/:loanId", controller.removeLoan);
router.post("/loanprocess/:borrowerId", controller.loanprocess);
router.post("/tRepayment/:borrowerId", controller.tRepayment);

module.exports = router;
