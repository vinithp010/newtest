const userModel = require('./user.model')
const tweetsModel = require('./tweets.model')
const followModel = require('./follow.model')


module.exports={
    userModel,
    tweetsModel,
    followModel
}
